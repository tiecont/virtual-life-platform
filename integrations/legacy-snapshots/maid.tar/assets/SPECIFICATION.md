# Art specification

Original Sakura café: cream #fff5e6, rose #d86b90, wood #895c45, mint #93c4a1, ink #352f44. Tiles 32×16 isometric; avatars 16×24, integer pixel scaling. Four starter palettes. Animation states idle/walk/sit/prepare/serve/emote, 4 frames each, 6 FPS. Pivot at feet; sort entities by y. Eight tables with three seats each, counter, kitchen, entrance, lounge and photo spot. No audio in MVP baseline. HTML controls mirror canvas interactions.
