# Asset provenance

No external assets imported. Planned sprites and tiles are original project-generated pixel artwork. Source generator, frame metadata and license inventory will accompany each produced asset. No copyrighted game characters, external fonts or sound. Owner copyright review required before public release.
