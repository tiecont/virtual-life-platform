import { z } from "zod";

export const CONTRACT_VERSION = 1;
export const RoleSchema = z.enum(["Customer", "Maid"]);
export const AvatarSchema = z.enum(["sakura", "mint", "lavender", "amber"]);
export const ProfileInputSchema = z.strictObject({
  nickname: z
    .string()
    .normalize("NFKC")
    .trim()
    .min(2)
    .max(24)
    .regex(
      /^[\p{L}\p{N} _-]+$/u,
      "Use letters, numbers, spaces, underscores or hyphens",
    ),
  avatar: AvatarSchema,
});
export const GuestInputSchema = ProfileInputSchema;
export const ErrorCodeSchema = z.enum([
  "UNAUTHENTICATED",
  "FORBIDDEN",
  "ROOM_FULL",
  "ROLE_FULL",
  "NOT_MEMBER",
  "INVALID_TARGET",
  "SEAT_OCCUPIED",
  "ORDER_NOT_FOUND",
  "ORDER_ALREADY_CLAIMED",
  "INVALID_ORDER_STATE",
  "SHIFT_REQUIRED",
  "MAX_ACTIVE_ORDERS",
  "RATE_LIMITED",
  "CHAT_REJECTED",
  "SANCTIONED",
  "CONFLICT_VERSION",
  "IDEMPOTENCY_CONFLICT",
  "RESYNC_REQUIRED",
  "INTERNAL_ERROR",
  "VALIDATION_ERROR",
  "SERVICE_UNAVAILABLE",
]);
export type ErrorCode = z.infer<typeof ErrorCodeSchema>;
export const PublicProfileSchema = z.strictObject({
  id: z.uuid(),
  nickname: z.string(),
  avatar: AvatarSchema,
});
export const RoomSummarySchema = z
  .strictObject({
    id: z.string().min(1).max(64),
    name: z.string(),
    version: z.number().int().nonnegative(),
    customers: z.number().int().nonnegative(),
    maids: z.number().int().nonnegative(),
    maxCustomers: z.number().int().nonnegative(),
    maxMaids: z.number().int().nonnegative(),
    maxTotal: z.number().int().min(1).max(30),
  })
  .refine(
    (r) =>
      r.customers + r.maids <= r.maxTotal &&
      r.customers <= r.maxCustomers &&
      r.maids <= r.maxMaids,
    "Invalid room occupancy",
  );
export const OrderStateSchema = z.enum([
  "PENDING",
  "ASSIGNED",
  "PREPARING",
  "READY",
  "SERVED",
  "COMPLETED",
  "CANCELLED",
]);
export const commandSchemas = {
  "room.join": z.strictObject({ role: RoleSchema }),
  "room.leave": z.strictObject({}),
  "room.snapshot": z.strictObject({}),
  "role.select": z.strictObject({ role: RoleSchema }),
  "seat.claim": z.strictObject({ seatId: z.string().min(1).max(64) }),
  "seat.release": z.strictObject({}),
  "player.move": z.strictObject({ targetPointId: z.string().min(1).max(64) }),
  "maid.shift.start": z.strictObject({}),
  "maid.shift.pause": z.strictObject({}),
  "maid.shift.end": z.strictObject({}),
  "order.place": z.strictObject({ menuItemId: z.string().min(1).max(64) }),
  "order.cancel": z.strictObject({ orderId: z.uuid() }),
  "order.claim": z.strictObject({ orderId: z.uuid() }),
  "order.prepare.start": z.strictObject({ orderId: z.uuid() }),
  "minigame.submit": z.strictObject({
    orderId: z.uuid(),
    attemptId: z.uuid(),
    nonce: z.string().min(32).max(128),
    ingredients: z.array(z.string().max(32)).min(1).max(8),
  }),
  "order.serve": z.strictObject({ orderId: z.uuid() }),
  "chat.send": z.strictObject({
    text: z.string().normalize("NFKC").trim().min(1).max(280),
  }),
  "quickchat.send": z.strictObject({
    phrase: z.enum([
      "hello",
      "thank-you",
      "order-please",
      "welcome",
      "goodbye",
    ]),
  }),
  "emote.send": z.strictObject({
    emote: z.enum(["wave", "bow", "thanks", "happy", "surprised"]),
  }),
  "user.block": z.strictObject({ targetId: z.uuid(), blocked: z.boolean() }),
  "report.create": z.strictObject({
    targetId: z.uuid(),
    messageId: z.uuid().optional(),
    category: z.enum([
      "harassment",
      "spam",
      "sexual-content",
      "threats",
      "personal-data",
      "other",
    ]),
    description: z.string().trim().max(500),
  }),
  "photo.consent.set": z.strictObject({ allowed: z.boolean() }),
} as const;
export type CommandName = keyof typeof commandSchemas;
export const CommandEnvelopeSchema = z.strictObject({
  requestId: z.uuid(),
  roomId: z.string().min(1).max(64),
  expectedVersion: z.number().int().nonnegative().optional(),
  payload: z.unknown(),
});
export type CommandEnvelope = z.infer<typeof CommandEnvelopeSchema>;
export const ErrorSchema = z.strictObject({
  code: ErrorCodeSchema,
  message: z.string(),
  retryable: z.boolean(),
});
export const AckSchema = z.discriminatedUnion("ok", [
  z.strictObject({
    requestId: z.uuid(),
    ok: z.literal(true),
    result: z.unknown(),
    roomVersion: z.number().int().nonnegative().optional(),
  }),
  z.strictObject({
    requestId: z.uuid(),
    ok: z.literal(false),
    error: ErrorSchema,
    roomVersion: z.number().int().nonnegative().optional(),
  }),
]);
export const RoomEventSchema = z.strictObject({
  eventId: z.uuid(),
  roomId: z.string(),
  version: z.number().int().nonnegative(),
  type: z.string(),
  payload: z.unknown(),
  occurredAt: z.iso.datetime(),
});
export type PublicProfile = z.infer<typeof PublicProfileSchema>;
export type RoomSummary = z.infer<typeof RoomSummarySchema>;
