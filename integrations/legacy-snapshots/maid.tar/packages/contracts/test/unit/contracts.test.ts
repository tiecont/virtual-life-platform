import { describe, it, expect } from "vitest";
import {
  GuestInputSchema,
  commandSchemas,
  CommandEnvelopeSchema,
  RoomSummarySchema,
  AckSchema,
  PublicProfileSchema,
} from "../../src";
import { randomUUID } from "node:crypto";
describe("version 1 serialized trust boundaries", () => {
  it("normalizes names and rejects privilege injection and markup", () => {
    expect(
      GuestInputSchema.parse({ nickname: "  Sakura  ", avatar: "mint" })
        .nickname,
    ).toBe("Sakura");
    expect(
      GuestInputSchema.safeParse({
        nickname: "Sakura",
        avatar: "mint",
        moderator: true,
      }).success,
    ).toBe(false);
    expect(
      GuestInputSchema.safeParse({ nickname: "<script>", avatar: "mint" })
        .success,
    ).toBe(false);
  });
  it("rejects arbitrary movement coordinates, invalid recipes and unknown item shapes", () => {
    expect(
      commandSchemas["player.move"].safeParse({
        targetPointId: "counter",
        x: 100,
      }).success,
    ).toBe(false);
    expect(
      commandSchemas["minigame.submit"].safeParse({
        orderId: randomUUID(),
        attemptId: randomUUID(),
        nonce: "too-short",
        ingredients: [],
      }).success,
    ).toBe(false);
    expect(
      commandSchemas["order.place"].safeParse({
        menuItemId: "coffee",
        customerId: randomUUID(),
      }).success,
    ).toBe(false);
  });
  it("retains request identity through browser serialization and requires a UUID", () => {
    const input = {
      requestId: randomUUID(),
      roomId: "cafe-sakura-1",
      expectedVersion: 0,
      payload: { role: "Customer" },
    };
    expect(
      CommandEnvelopeSchema.parse(JSON.parse(JSON.stringify(input))),
    ).toEqual(input);
    expect(
      CommandEnvelopeSchema.safeParse({ ...input, requestId: "replay" })
        .success,
    ).toBe(false);
  });
  it("rejects impossible room occupancy and private fields in profiles", () => {
    expect(
      RoomSummarySchema.safeParse({
        id: "one",
        name: "One",
        version: 0,
        customers: 25,
        maids: 6,
        maxCustomers: 24,
        maxMaids: 6,
        maxTotal: 30,
      }).success,
    ).toBe(false);
    expect(
      PublicProfileSchema.safeParse({
        id: randomUUID(),
        nickname: "Sakura",
        avatar: "sakura",
        token: "secret",
      }).success,
    ).toBe(false);
  });
  it("requires typed errors in failed ACKs", () => {
    expect(
      AckSchema.safeParse({
        requestId: randomUUID(),
        ok: false,
        error: { code: "FORBIDDEN", message: "Denied", retryable: false },
      }).success,
    ).toBe(true);
    expect(
      AckSchema.safeParse({
        requestId: randomUUID(),
        ok: false,
        error: { code: "SQL_PASSWORD", message: "secret", retryable: false },
      }).success,
    ).toBe(false);
  });
});
