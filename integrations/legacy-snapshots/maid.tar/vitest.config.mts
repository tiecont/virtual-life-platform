import { defineConfig } from "vitest/config";
export default defineConfig({
  test: {
    projects: ["unit", "integration", "concurrency"].map((name) => ({
      test: {
        name,
        include: [`**/test/${name}/**/*.test.ts`],
        testTimeout: 20000,
        hookTimeout: 20000,
      },
    })),
  },
});
