# Maid Cafe Social

Implementation of the included master plan. Current verified scope and unfinished tasks are recorded in [agent progress](docs/agent/PROGRESS.md). This is not a public release.

## Local development

Requires Node 24 LTS (Node 26 also supported), pnpm 11.28.5, Docker Compose or PostgreSQL 18.6. One API instance owns all ephemeral rooms. Never run multiple replicas without owner routing.

```sh
pnpm install --frozen-lockfile
cp .env.example .env
# Set LOCAL_DB_PASSWORD and matching DATABASE_URL credentials in .env.
docker compose --env-file .env -f infra/compose/local.yaml up -d --wait
pnpm --filter @maid/contracts build
pnpm db:migrate
pnpm db:seed
pnpm dev
```

Open http://127.0.0.1:3000. API liveness: http://127.0.0.1:4000/health/live; readiness checks PostgreSQL. Use 127.0.0.1 consistently: exact Origin checks reject localhost if WEB_ORIGIN uses 127.0.0.1. The API dev command loads the root .env.

## Verification

```sh
pnpm lint
pnpm typecheck
pnpm test:unit
pnpm test:integration
pnpm exec playwright install chromium
pnpm test:e2e
pnpm build
```

Integration tests create a disposable Docker Compose test database when TEST_DATABASE_URL is unset. If supplying a database, its name must begin with maid_cafe_test; each run uses a unique schema and removes only that schema. Never point tests at production. E2E needs an already migrated/seeded DATABASE_URL and starts real web/API processes. No mocked backend is used in integration/E2E. Concurrency and load commands will be added with the domain phases; they are not implemented yet.

## Configuration and operations

See .env.example for documented defaults. DATABASE_URL is required, WEB_ORIGIN is an exact browser origin, PORT defaults to 4000, SESSION_TTL_SECONDS defaults to 86400. Production requires an HTTPS WEB_ORIGIN. Keep secrets out of Git. Readiness returns 503 when PostgreSQL is unavailable without exposing connection errors. Logs omit cookies, Authorization and bodies.

Migrations are transactional and serialized with an advisory lock. Applied files have SHA256 checksums and must never be edited: add a new forward migration. Seeds insert missing catalog entries without overwriting operator edits. No destructive reset command is supplied. Rollback requires a compatible app version; do not drop tables to reverse a release. Docker local data persists in a named volume.

If Docker access or socket binding is denied, see docs/agent/BLOCKERS.md. Do not treat unit-level HTTP injection as proof of deployed HTTP/WSS connectivity. CI configuration exists but a green remote run needs a GitHub repository and push.

## Assets and safety

See assets/SPECIFICATION.md and assets/LICENSES.md. No third-party art is imported. Public launch requires an owner-reviewed age/privacy policy, licensed assets, moderator operators, contact address and authorized infrastructure. The master plan requires server-enforced report/block/moderation before launch.
