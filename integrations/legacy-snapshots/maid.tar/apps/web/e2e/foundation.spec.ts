import { test, expect } from "@playwright/test";
test("P01 web shell and real API/database are available", async ({
  page,
  request,
}) => {
  const ready = await request.get("http://127.0.0.1:4000/health/ready");
  expect(ready.ok()).toBe(true);
  await page.goto("/");
  await expect(
    page.getByRole("heading", { name: "A little café. Made together." }),
  ).toBeVisible();
  await expect(
    page.getByRole("link", { name: "Enter Café Sakura" }),
  ).toBeVisible();
  await page.screenshot({
    path: "test-results/P01-landing.png",
    fullPage: true,
  });
});
