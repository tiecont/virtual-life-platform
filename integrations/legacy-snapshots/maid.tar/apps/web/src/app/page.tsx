export default function Home() {
  return (
    <main>
      <p>SAKURA · SOCIAL ROLEPLAY</p>
      <h1>
        A little café.
        <br />
        Made together.
      </h1>
      <p>Find a seat, make a drink, and meet someone new.</p>
      <p>
        Customer and Maid roles are open to everyone. Maid players are
        volunteers.
      </p>
      <a href="/play">Enter Café Sakura</a>
    </main>
  );
}
