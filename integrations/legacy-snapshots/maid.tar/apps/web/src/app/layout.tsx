import "./globals.css";
export const metadata = {
  title: "Maid Cafe Social",
  description: "A cozy multiplayer café, made together.",
};
export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
