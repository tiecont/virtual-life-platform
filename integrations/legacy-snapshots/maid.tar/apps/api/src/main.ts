import { createApp } from "./app";
import { readConfig } from "./common/config";
import { createDatabase } from "./db/client";
async function main() {
  const config = readConfig();
  const db = createDatabase(config.DATABASE_URL);
  const app = await createApp(config, db);
  let stopping = false;
  const stop = async () => {
    if (stopping) return;
    stopping = true;
    await app.close();
    await db.close();
  };
  process.once("SIGTERM", () => void stop());
  process.once("SIGINT", () => void stop());
  try {
    await app.listen(config.PORT, "0.0.0.0");
  } catch (error) {
    await stop();
    throw error;
  }
}
main().catch(() => {
  console.error(JSON.stringify({ level: "fatal", event: "startup.failed" }));
  process.exitCode = 1;
});
