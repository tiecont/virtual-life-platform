import type { Database } from "./client";
import { cafeTemplates, menuItems, cosmeticCatalog } from "./schema";
import { cafe, menu } from "./catalog";
export async function seed(db: Database) {
  await db.orm.transaction(async (tx) => {
    await tx
      .insert(cafeTemplates)
      .values({ id: cafe.id, slug: cafe.slug, config: cafe })
      .onConflictDoNothing();
    for (const item of menu)
      await tx
        .insert(menuItems)
        .values({
          id: item.id,
          cafeId: cafe.id,
          slug: item.id,
          title: item.title,
          recipe: item.recipe,
        })
        .onConflictDoNothing();
    for (const color of ["sakura", "mint", "lavender", "amber"])
      await tx
        .insert(cosmeticCatalog)
        .values({
          id: "starter-" + color,
          kind: "outfit",
          assetKey: color,
          unlockCondition: { starter: true },
        })
        .onConflictDoNothing();
  });
}
