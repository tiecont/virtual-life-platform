CREATE TABLE users (
 id uuid PRIMARY KEY, kind text NOT NULL CHECK(kind IN ('guest','registered','moderator')),
 status text NOT NULL DEFAULT 'active' CHECK(status IN ('active','disabled')),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE sessions (
 id uuid PRIMARY KEY, user_id uuid NOT NULL REFERENCES users(id), token_hash text NOT NULL UNIQUE,
 expires_at timestamptz NOT NULL, revoked_at timestamptz, created_at timestamptz NOT NULL DEFAULT now(),
 CHECK(length(token_hash)=64), CHECK(expires_at>created_at)
);
CREATE INDEX sessions_user ON sessions(user_id);
CREATE INDEX sessions_expiry ON sessions(expires_at);
CREATE TABLE profiles (
 user_id uuid PRIMARY KEY REFERENCES users(id), display_name text NOT NULL CHECK(length(display_name) BETWEEN 2 AND 24),
 avatar_key text NOT NULL CHECK(avatar_key IN ('sakura','mint','lavender','amber')),
 preferences_json jsonb NOT NULL DEFAULT '{}', updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE cafe_templates (
 id text PRIMARY KEY, slug text NOT NULL UNIQUE, config_json jsonb NOT NULL,
 enabled integer NOT NULL DEFAULT 1 CHECK(enabled IN (0,1))
);
CREATE TABLE menu_items (
 id text PRIMARY KEY, cafe_id text NOT NULL REFERENCES cafe_templates(id), slug text NOT NULL,
 title text NOT NULL, virtual_price integer NOT NULL DEFAULT 0 CHECK(virtual_price>=0),
 recipe_json jsonb NOT NULL, active integer NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
 UNIQUE(cafe_id,slug)
);
CREATE TABLE cosmetic_catalog (
 id text PRIMARY KEY, kind text NOT NULL, asset_key text NOT NULL,
 active integer NOT NULL DEFAULT 1 CHECK(active IN (0,1)), unlock_condition_json jsonb NOT NULL DEFAULT '{}'
);
