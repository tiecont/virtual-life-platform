import { createDatabase } from "./client";
import { readConfig } from "../common/config";
import { seed } from "./seeding";
async function main() {
  const db = createDatabase(readConfig().DATABASE_URL);
  try {
    await seed(db);
    console.log(
      "Cafe, six menu items and four starter cosmetics seeded idempotently",
    );
  } finally {
    await db.close();
  }
}
main().catch(() => {
  console.error("Seed failed; run migrations and verify database connectivity");
  process.exitCode = 1;
});
