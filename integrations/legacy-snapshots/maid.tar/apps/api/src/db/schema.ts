import {
  pgTable,
  uuid,
  text,
  timestamp,
  integer,
  jsonb,
  uniqueIndex,
} from "drizzle-orm/pg-core";
export const users = pgTable("users", {
  id: uuid().primaryKey(),
  kind: text().notNull(),
  status: text().notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});
export const profiles = pgTable("profiles", {
  userId: uuid("user_id")
    .primaryKey()
    .references(() => users.id),
  displayName: text("display_name").notNull(),
  avatarKey: text("avatar_key").notNull(),
  preferences: jsonb("preferences_json").notNull().default({}),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});
export const sessions = pgTable("sessions", {
  id: uuid().primaryKey(),
  userId: uuid("user_id")
    .notNull()
    .references(() => users.id),
  tokenHash: text("token_hash").notNull().unique(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  revokedAt: timestamp("revoked_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});
export const cafeTemplates = pgTable("cafe_templates", {
  id: text().primaryKey(),
  slug: text().notNull().unique(),
  config: jsonb("config_json").notNull(),
  enabled: integer().notNull().default(1),
});
export const menuItems = pgTable(
  "menu_items",
  {
    id: text().primaryKey(),
    cafeId: text("cafe_id")
      .notNull()
      .references(() => cafeTemplates.id),
    slug: text().notNull(),
    title: text().notNull(),
    virtualPrice: integer("virtual_price").notNull().default(0),
    recipe: jsonb("recipe_json").notNull(),
    active: integer().notNull().default(1),
  },
  (t) => [uniqueIndex("menu_cafe_slug").on(t.cafeId, t.slug)],
);
export const cosmeticCatalog = pgTable("cosmetic_catalog", {
  id: text().primaryKey(),
  kind: text().notNull(),
  assetKey: text("asset_key").notNull(),
  active: integer().notNull().default(1),
  unlockCondition: jsonb("unlock_condition_json").notNull().default({}),
});
