export const cafe = {
  id: "cafe-sakura",
  slug: "cafe-sakura",
  maxTotal: 30,
  maxCustomer: 24,
  maxMaid: 6,
};
export const menu = [
  { id: "coffee", title: "Coffee", recipe: ["coffee", "water"] },
  { id: "iced-latte", title: "Iced Latte", recipe: ["ice", "coffee", "milk"] },
  { id: "milk-tea", title: "Milk Tea", recipe: ["tea", "milk"] },
  { id: "matcha", title: "Matcha", recipe: ["matcha", "water", "milk"] },
  { id: "cake", title: "Cake", recipe: ["sponge", "cream", "strawberry"] },
  { id: "omurice", title: "Omurice", recipe: ["rice", "egg", "sauce"] },
] as const;
