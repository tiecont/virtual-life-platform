import { createDatabase } from "./client";
import { readConfig } from "../common/config";
import { migrate } from "./migrations";
async function main() {
  const db = createDatabase(readConfig().DATABASE_URL);
  try {
    await migrate(db.pool);
    console.log("Migrations applied and checksums verified");
  } finally {
    await db.close();
  }
}
main().catch(() => {
  console.error(
    "Migration failed; inspect database availability and migration checksums",
  );
  process.exitCode = 1;
});
