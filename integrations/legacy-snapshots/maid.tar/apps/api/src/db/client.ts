import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import * as schema from "./schema";
export function createDatabase(connectionString: string) {
  const pool = new Pool({
    connectionString,
    max: 10,
    connectionTimeoutMillis: 3000,
    idleTimeoutMillis: 30000,
    statement_timeout: 5000,
    application_name: "maid-cafe",
  });
  pool.on("error", () =>
    process.stderr.write(
      JSON.stringify({ level: "error", event: "database.pool.error" }) + "\n",
    ),
  );
  return { pool, orm: drizzle(pool, { schema }), close: () => pool.end() };
}
export type Database = ReturnType<typeof createDatabase>;
