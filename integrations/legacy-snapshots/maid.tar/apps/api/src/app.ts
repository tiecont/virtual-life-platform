import "reflect-metadata";
import { Module } from "@nestjs/common";
import { NestFactory } from "@nestjs/core";
import {
  FastifyAdapter,
  type NestFastifyApplication,
} from "@nestjs/platform-fastify";
import type { Config } from "./common/config";
import type { Database } from "./db/client";
import { randomUUID } from "node:crypto";

class AppModule {}
Module({})(AppModule);
export async function createApp(config: Config, db: Pick<Database, "pool">) {
  const app = await NestFactory.create<NestFastifyApplication>(
    AppModule,
    new FastifyAdapter({
      bodyLimit: 16384,
      requestTimeout: 10000,
      logger: {
        level: config.NODE_ENV === "test" ? "silent" : "info",
        redact: [
          "req.headers.cookie",
          "req.headers.authorization",
          "req.body",
          "res.headers.set-cookie",
        ],
        serializers: {
          req: (req: { method: string; url: string }) => ({
            method: req.method,
            path: req.url.split("?")[0],
          }),
        },
      },
      genReqId: () => randomUUID(),
    }),
    { logger: false },
  );
  const server = app.getHttpAdapter().getInstance();
  server.addHook("onRequest", async (request, reply) => {
    reply.header("X-Content-Type-Options", "nosniff");
    reply.header("Cache-Control", "no-store");
    reply.header("X-Request-Id", request.id);
    if (
      !["GET", "HEAD", "OPTIONS"].includes(request.method) &&
      request.headers.origin !== config.WEB_ORIGIN
    ) {
      return reply
        .code(403)
        .send({
          error: {
            code: "FORBIDDEN",
            message: "Origin not allowed",
            retryable: false,
          },
        });
    }
  });
  server.get("/health/live", async () => ({ status: "ok" }));
  server.get("/health/ready", async (_request, reply) => {
    try {
      await db.pool.query("SELECT 1");
      return { status: "ready" };
    } catch {
      return reply.code(503).send({ status: "unavailable" });
    }
  });
  await app.init();
  server.setErrorHandler((error, _request, reply) => {
    const code =
      error instanceof Error && "statusCode" in error
        ? error.statusCode
        : undefined;
    const status =
      typeof code === "number" && code >= 400 && code < 500 ? code : 500;
    return reply
      .code(status)
      .send({
        error: {
          code: status === 500 ? "INTERNAL_ERROR" : "VALIDATION_ERROR",
          message:
            status === 500
              ? "The request could not be completed"
              : "Invalid request",
          retryable: false,
        },
      });
  });

  await server.ready();
  return app;
}
