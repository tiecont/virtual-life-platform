import { z } from "zod";
const schema = z
  .object({
    NODE_ENV: z
      .enum(["development", "test", "production"])
      .default("development"),
    PORT: z.coerce.number().int().min(1).max(65535).default(4000),
    DATABASE_URL: z.string().min(1),
    WEB_ORIGIN: z.url().default("http://127.0.0.1:3000"),
    SESSION_TTL_SECONDS: z.coerce
      .number()
      .int()
      .min(300)
      .max(604800)
      .default(86400),
  })
  .superRefine((value, ctx) => {
    if (
      value.NODE_ENV === "production" &&
      !value.WEB_ORIGIN.startsWith("https://")
    )
      ctx.addIssue({
        code: "custom",
        message: "Production WEB_ORIGIN must use HTTPS",
        path: ["WEB_ORIGIN"],
      });
    const url = new URL(value.WEB_ORIGIN);
    if (url.origin !== value.WEB_ORIGIN)
      ctx.addIssue({
        code: "custom",
        message: "WEB_ORIGIN must be an origin without path or credentials",
        path: ["WEB_ORIGIN"],
      });
    if (!/^postgres(ql)?:\/\//.test(value.DATABASE_URL))
      ctx.addIssue({
        code: "custom",
        message: "DATABASE_URL must use PostgreSQL",
        path: ["DATABASE_URL"],
      });
  });
export type Config = z.infer<typeof schema>;
export function readConfig(env: NodeJS.ProcessEnv = process.env): Config {
  const result = schema.safeParse(env);
  if (!result.success)
    throw new Error(
      "Invalid configuration: " +
        result.error.issues
          .map((i) => i.path.join(".") + ": " + i.message)
          .join("; "),
    );
  return result.data;
}
