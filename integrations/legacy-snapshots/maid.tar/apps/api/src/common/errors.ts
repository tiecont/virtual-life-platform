import type { ErrorCode } from "@maid/contracts";
export class DomainError extends Error {
  constructor(
    public readonly code: ErrorCode,
    message: string,
    public readonly status = 400,
    public readonly retryable = false,
  ) {
    super(message);
  }
}
export function publicError(error: unknown) {
  return error instanceof DomainError
    ? { code: error.code, message: error.message, retryable: error.retryable }
    : {
        code: "INTERNAL_ERROR" as const,
        message: "The request could not be completed",
        retryable: false,
      };
}
