import { beforeAll, afterAll, describe, it, expect } from "vitest";
import { randomUUID } from "node:crypto";
import { Pool } from "pg";
import { createDatabase, type Database } from "../../src/db/client";
import { migrate } from "../../src/db/migrations";
import { seed } from "../../src/db/seeding";
import { createApp } from "../../src/app";
import { readConfig } from "../../src/common/config";
let db: Database;
let admin: Pool;
const schema = "test_" + randomUUID().replaceAll("-", "");
beforeAll(async () => {
  const connectionString = process.env.TEST_DATABASE_URL;
  if (
    !connectionString ||
    !/^maid_cafe_test(?:_|$)/.test(new URL(connectionString).pathname.slice(1))
  )
    throw new Error(
      "TEST_DATABASE_URL must target an isolated maid_cafe_test database; never use production",
    );
  admin = new Pool({ connectionString, connectionTimeoutMillis: 3000 });
  await admin.query(`CREATE SCHEMA "${schema}"`);
  const url = new URL(connectionString);
  url.searchParams.set("options", `-c search_path=${schema}`);
  db = createDatabase(url.toString());
  await migrate(db.pool);
  await seed(db);
});
afterAll(async () => {
  if (db) await db.close();
  if (admin) {
    await admin.query(`DROP SCHEMA IF EXISTS "${schema}" CASCADE`);
    await admin.end();
  }
});
describe("P01 real PostgreSQL foundation", () => {
  it("migrates and seeds twice without duplication", async () => {
    await migrate(db.pool);
    await seed(db);
    expect(
      (await db.pool.query("SELECT count(*)::int AS n FROM menu_items")).rows[0]
        .n,
    ).toBe(6);
    expect(
      (await db.pool.query("SELECT count(*)::int AS n FROM cosmetic_catalog"))
        .rows[0].n,
    ).toBe(4);
    expect(
      (await db.pool.query("SELECT count(*)::int AS n FROM schema_migrations"))
        .rows[0].n,
    ).toBe(1);
  });
  it("enforces foreign keys and nonnegative price at the database boundary", async () => {
    await expect(
      db.pool.query(
        "INSERT INTO menu_items(id,cafe_id,slug,title,recipe_json) VALUES('bad','missing','bad','Bad','[]')",
      ),
    ).rejects.toMatchObject({ code: "23503" });
    await expect(
      db.pool.query("UPDATE menu_items SET virtual_price=-1 WHERE id='coffee'"),
    ).rejects.toMatchObject({ code: "23514" });
  });
  it("checks real DB readiness through the Nest HTTP adapter", async () => {
    const app = await createApp(
      readConfig({
        NODE_ENV: "test",
        DATABASE_URL: process.env.TEST_DATABASE_URL,
      }),
      db,
    );
    try {
      const response = await app.inject({ url: "/health/ready" });
      expect(response.statusCode).toBe(200);
      expect(response.json()).toEqual({ status: "ready" });
    } finally {
      await app.close();
    }
  });
  it("detects modified historical migrations without applying new writes", async () => {
    await db.pool.query("UPDATE schema_migrations SET checksum='tampered'");
    await expect(migrate(db.pool)).rejects.toThrow("checksum mismatch");
  });
});
