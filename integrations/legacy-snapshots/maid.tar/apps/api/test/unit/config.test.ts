import { describe, it, expect } from "vitest";
import { readConfig } from "../../src/common/config";
import { DomainError, publicError } from "../../src/common/errors";
const base = { DATABASE_URL: "postgresql://localhost/maid_cafe" };
describe("configuration trust boundary", () => {
  it("rejects missing database credentials without echoing environment secrets", () => {
    expect(() => readConfig({})).toThrow("DATABASE_URL");
  });
  it("requires production HTTPS and an exact origin", () => {
    expect(() => readConfig({ ...base, NODE_ENV: "production" })).toThrow(
      "HTTPS",
    );
    expect(() =>
      readConfig({
        ...base,
        WEB_ORIGIN: "https://user:password@example.com/path",
      }),
    ).toThrow("origin");
    expect(
      readConfig({
        ...base,
        NODE_ENV: "production",
        WEB_ORIGIN: "https://cafe.example.com",
      }).PORT,
    ).toBe(4000);
  });
  it("rejects invalid session TTL, database protocol and port", () => {
    for (const override of [
      { SESSION_TTL_SECONDS: "1" },
      { PORT: "0" },
      { DATABASE_URL: "sqlite://secret" },
    ])
      expect(() => readConfig({ ...base, ...override })).toThrow(
        "Invalid configuration",
      );
  });
  it("redacts internal errors while retaining public typed errors", () => {
    expect(publicError(new Error("password=private"))).toEqual({
      code: "INTERNAL_ERROR",
      message: "The request could not be completed",
      retryable: false,
    });
    expect(
      publicError(new DomainError("ROOM_FULL", "Room full", 409)),
    ).toMatchObject({ code: "ROOM_FULL", message: "Room full" });
  });
});
