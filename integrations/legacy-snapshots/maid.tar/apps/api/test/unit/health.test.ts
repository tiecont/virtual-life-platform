import { describe, it, expect, vi } from "vitest";
import { createApp } from "../../src/app";
import { readConfig } from "../../src/common/config";
import type { Database } from "../../src/db/client";
// Unit-only dependency doubles exercise failure serialization, not database readiness acceptance.
const config = readConfig({
  NODE_ENV: "test",
  DATABASE_URL: "postgresql://localhost/maid_cafe_test_unit",
});
describe("health HTTP behavior without binding sockets", () => {
  it("separates liveness from failing DB readiness and returns no connection secrets", async () => {
    const query = vi
      .fn()
      .mockRejectedValue(new Error("postgres://secret:password@private"));
    const app = await createApp(config, {
      pool: { query } as unknown as Database["pool"],
    });
    try {
      const live = await app.inject({ url: "/health/live" });
      expect(live.statusCode).toBe(200);
      expect(live.json()).toEqual({ status: "ok" });
      expect(query).not.toHaveBeenCalled();
      const ready = await app.inject({ url: "/health/ready" });
      expect(ready.statusCode).toBe(503);
      expect(ready.body).not.toContain("password");
      expect(live.headers["x-content-type-options"]).toBe("nosniff");
      expect(live.headers["x-request-id"]).toBeTruthy();
    } finally {
      await app.close();
    }
  });
  it("rejects cross-origin mutations before routing", async () => {
    const app = await createApp(config, {
      pool: { query: vi.fn() } as unknown as Database["pool"],
    });
    try {
      const result = await app.inject({
        method: "POST",
        url: "/not-a-route",
        headers: { origin: "https://attacker.example" },
      });
      expect(result.statusCode).toBe(403);
      expect(result.json().error.code).toBe("FORBIDDEN");
    } finally {
      await app.close();
    }
  });
});
