import { defineConfig, devices } from "@playwright/test";
if (!process.env.DATABASE_URL)
  throw new Error("DATABASE_URL required for real API + DB E2E");
export default defineConfig({
  testDir: "apps/web/e2e",
  reporter: [["list"], ["html", { open: "never" }]],
  use: {
    baseURL: "http://127.0.0.1:3000",
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
  },
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"] } }],
  webServer: [
    {
      command: "pnpm --filter @maid/api dev",
      url: "http://127.0.0.1:4000/health/ready",
      reuseExistingServer: false,
      timeout: 60000,
    },
    {
      command: "pnpm --filter @maid/web dev",
      url: "http://127.0.0.1:3000",
      reuseExistingServer: false,
      timeout: 60000,
    },
  ],
});
