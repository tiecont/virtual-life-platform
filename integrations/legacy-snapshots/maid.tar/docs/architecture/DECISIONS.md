# Architecture decisions — 2026-11-02

1. Use the master-plan baseline: pnpm, strict TypeScript, Next/React/Tailwind, Pixi, Zustand, Nest/Fastify/Socket.IO, Zod, PostgreSQL/Drizzle. One deployable API instance. Keep domain logic independent of transport.
2. One serialized command queue per room, bounded identities and receipts. No async room mutation outside its queue. Snapshot versioning detects gaps; reconnect uses a complete snapshot.
3. Database CAS controls order ownership. Receipts bind actor + request ID to payload hash. Complete and rewards share a transaction with unique ledger keys. Persist before publishing.
4. Secure opaque cookie sessions stored as hashes. Guest and moderator capabilities are separate. Origin validation applies to HTTP mutations and socket handshakes. Moderation runs before broadcast.
5. Ephemeral rooms are lost on restart. Reconcile nonterminal persisted orders to CANCELLED with audit before accepting joins. No reward for recovery cancellation.
6. Scale only after measured capacity failure. Redis broadcast alone does not give room ownership; owner routing, leases/fencing and failover tests are prerequisites for replicas.
7. Produce original code-native pixel assets, track generator/source/license and dimensions. No external game/anime assets, fonts or audio. Owner review remains required before launch.
8. Empty workspace has protected .git directory; commits may be blocked. Do not modify the protection. Docker socket is denied; attempt isolated local PostgreSQL before declaring DB testing blocked.
