# Blockers

- BLK-001 RESOLVED (git init succeeded): .git is a protected read-only empty directory; no repository metadata exists. Commit evidence unavailable until owner supplies writable Git metadata. Never fabricate commit hashes.
- BLK-002 TECHNICAL: docker info returns permission denied for /var/run/docker.sock. Investigate local PostgreSQL for integration tests; container verification remains unavailable.
- BLK-003 EXTERNAL: Public release needs owner-provided infrastructure, secrets, domain/TLS, age/privacy policy, moderation contact, asset approval and human playtest participants (plan §17). Continue local implementation.
