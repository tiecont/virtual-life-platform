# Phase dependencies

P00 → P01 → P02 → P03 → P04 → P05 → P06. P07 requires P04/P05. P08 requires P02–P07. P09 requires P03–P08. P10 requires P01/P09. P11 requires all preceding gates. Task checklist lives in PROGRESS.md. External release gates remain explicit and do not justify skipping unblocked implementation.
