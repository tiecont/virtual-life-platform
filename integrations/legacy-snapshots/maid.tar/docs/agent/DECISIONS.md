# Agent decisions

See ../architecture/DECISIONS.md. Source plan copied without edits from Downloads. Original scope and dependency order retained. No production deployment authorized.
