# Community rules

Be kind. No harassment, threats, sexual content, hate, spam, impersonation, or personal data sharing. Maid players are volunteers, not moderators. Respect refusals and photo consent. Use block/report in the safety menu; leave a room whenever uncomfortable. No payments or trading. Public launch requires an owner-approved age policy and abuse contact.
