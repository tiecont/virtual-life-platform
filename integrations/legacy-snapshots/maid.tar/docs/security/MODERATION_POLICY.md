## 7. SECURITY, SAFETY & MODERATION

### 7.1 Threat model

**Tài sản cần bảo vệ:** identity/session; quyền moderation; trạng thái order/reward; an toàn chat; dữ liệu báo cáo; độ sẵn sàng service.

**Mối đe dọa:** anonymous spam, sockpuppets, session theft, CSRF, forged socket events, privilege escalation, seat/order race, duplicate reward, bot farming, chat harassment, personal info leaks, DoS, reconnect storms.

### 7.2 Controls bắt buộc

- Server validation với Zod cho từng HTTP/socket payload và strict allowlist event types.
- Signed high-entropy sessions, secure cookies, rotation/revocation, moderate session TTL.
- Same-origin/correct CORS, socket Origin allowlist; không open `*` với credentials.
- HTTP CSRF protection cho mutations (Origin checks + CSRF token khi thích hợp).
- Per-IP (privacy respecting), per-session, per-room, per-command rate limits; payload size caps.
- Socket connection caps, idle timeout, load shedding, structured error handling.
- Content moderation trước broadcast: text normalization, abuse/profanity/PII heuristic, spam detection, policy rules; suspicious content held for review; warn/block accordingly.
- Chat safety policy viết bằng ngôn ngữ rõ, có báo cáo và appeals; moderation staff không là Maid mặc định.
- Moderator/admin accounts không guest; mạnh authentication, recommended MFA, RBAC, audit logs; bootstrap via protected admin command/secrets, không self-register moderator.
- Secrets không commit repo; `.env.example` chỉ chứa tên biến, CI secret scanning.
- Set CSP, secure headers, data access boundaries; test dependency vulnerabilities trước release.

### 7.3 Report lifecycle

`OPEN → TRIAGED → ACTIONED / DISMISSED → CLOSED`, có `REOPENED` qua appeal nếu cần.

- Reporter chọn player/message, reason (harassment, spam, sexual content, threats, personal data, others), optional description.
- Report tạo trên server với trusted message reference; không cho client gửi bằng chứng giả như message của người khác.
- Moderator queue show timestamp + context tối thiểu, history đã được phép xem.
- Action with reason and TTL; log audit; thông báo kết quả không tiết lộ chi tiết riêng tư cho người không có quyền.
- Thử report spam, report malicious, self-report và cross-room report.

### 7.4 Age-safety / public launch gate

Trước khi mở public phải xác định đối tượng tuổi và chính sách độ tuổi, hiển thị quy tắc cộng đồng, privacy policy, contact for abuse, cookie/analytics notice phù hợp. Nếu không có năng lực bảo vệ trẻ vị thành niên, **không định vị sản phẩm cho trẻ em** và thiết kế onboarding/giới hạn theo chính sách pháp lý đã rà soát. Không tự tuyên bố tuân thủ pháp luật một quốc gia mà chưa được kiểm tra.

### 7.5 Security acceptance tests

- Blocked chat sender gửi raw Socket.IO event → server reject.
- Non-mod gọi `/v1/mod/*` → 403.
- Banned user refresh/reconnect/new tab → không join.
- Duplicate requestId with different payload → `IDEMPOTENCY_CONFLICT`.
- Stolen/invalid/expired token → unauthorized; redact logs.
- Rate limited user bị từ chối trước DB-heavy work.
- Inputs with HTML/JS không tạo XSS khi hiển thị.
- Report evidence không truy cập được bởi user không có quyền.

---


Review procedure: triage trusted evidence; record policy reason, actor, duration and timestamp; notify target without exposing reporter. Appeals reopen a decision for a different reviewer where available. No guest can obtain moderator privileges. Bootstrap privileged credentials only through an operator command.
