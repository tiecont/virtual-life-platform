## 1. PRODUCT REQUIREMENTS DOCUMENT (PRD)

### 1.1 Vision

**Maid Cafe Social** là một social roleplay game 2D trên trình duyệt: người dùng nhập vai **Customer** hoặc **Maid** (người phục vụ), cùng vận hành quán cà phê anime-inspired. Người chơi có mục tiêu nhẹ nhàng, các hành vi phối hợp hữu ích, các hoạt động vui và trải nghiệm an toàn với người lạ.

**North-star experience:** Một khách chọn bàn, gọi món; một Maid người thật nhận đơn, pha chế, mang món tới; cả hai tương tác bằng emote/chat đã được kiểm duyệt; kết thúc bằng ảnh kỷ niệm/EXP. Toàn bộ vòng lặp hoạt động cho nhiều người chơi đồng thời.

### 1.2 Đối tượng & giá trị

| Nhóm | Nhu cầu chính | Giá trị sản phẩm |
|---|---|---|
| Người thích anime/pixel art | Trải nghiệm vui và chia sẻ | Quán ảo đẹp, avatar chibi, sự kiện |
| Người chơi social casual | Gặp gỡ, tương tác nhanh | Room multiplayer, trò chuyện, emotes |
| Người thích roleplay phục vụ | Có hoạt động và tiến độ | Maid shift, order queue, minigame, EXP |
| Nhóm bạn | Cùng vào một phòng | Invite link, chỗ ngồi gần nhau nếu còn |

### 1.3 Product principles

- Join nhanh, **không cần đăng ký** cho người mới; guest identity có kiểm soát lạm dụng.
- Player Maid là người thật tự nguyện; **không đồng nghĩa moderator/nhân viên công ty**.
- Trang phục và vai trò không giới hạn giới tính; không thiết kế nội dung tình dục hay cơ chế “trả tiền để nhận sự quan tâm”.
- Không bắt buộc giao tiếp riêng. Có quyền từ chối/tắt tương tác, mute, block, chuyển phòng.
- Khi quán vắng vẫn có việc để làm nhờ NPC fallback **được gắn nhãn NPC rõ ràng**.
- Người chơi có thể chơi trên desktop; mobile có cơ chế touch-to-move và UI thu gọn.
- Chất lượng hình ảnh, onboarding và moderation quan trọng tương đương backend.

### 1.4 Scope MVP bắt buộc

1. Landing + onboarding + nickname/avatar cơ bản + guest session.
2. Lobby: danh sách room, số người thực tế, chỗ trống, join/invite.
3. Một map Café Sakura isometric 2D và các vị trí tương tác.
4. Chọn vai Customer/Maid, capacity riêng từng vai, role switching an toàn.
5. Realtime room, presence, seat allocation, movement theo điểm đích, reconnect + snapshot.
6. Customer menu gồm **6 món** cấu hình bằng dữ liệu, đặt/hủy đơn theo quy tắc.
7. Maid shift, nhận đơn, pha chế bằng **1 minigame ngắn**, phục vụ tại bàn.
8. NPC fallback giới hạn khi không có Maid và thời gian chờ đạt ngưỡng.
9. Room chat có moderation; quick-chat; emote; mute/block/report.
10. Moderator dashboard: báo cáo, bằng chứng tối thiểu, mute/kick/temporary ban, action audit và quyền truy cập đúng.
11. EXP + một số rewards cosmetic, profile tối giản; friend invite; cheki/screenshot với consent.
12. Logging, metrics, CI/CD, backup-restore, security, test suite, docs vận hành.

### 1.5 Ngoài phạm vi MVP (hard non-goals)

- AI Maid LLM / tình cảm ảo, voice chat, livestream, video, webcam, 1:1 direct messages.
- Payment, virtual goods mua bằng tiền thật, user-to-user trading, gift/tip trả phí.
- User-generated images, audio, arbitrary text on sprites, uploads công khai.
- World editor, nhiều map và sự kiện theo mùa tự động.
- Kubernetes, Kafka, Elasticsearch, microservices, distributed transaction orchestrator.
- 3D/VR, movement vật lý kiểu MMO, competitive combat.
- Xếp hạng người chơi dựa vào mức độ được người khác chú ý.

### 1.6 MVP content specification

- **Một quán** `cafe-sakura`, có khu lobby, dining (8 bàn x 3 ghế hoặc phương án tương đương), counter, kitchen, photo spot, social corner; cấu hình room tối đa 30 participants.
- **Room quota mặc định:** 24 Customer + 6 Maid; phải config được và tuân thủ tổng ≤ 30.
- **6 món menu:** Coffee, Iced Latte, Milk Tea, Matcha, Cake, Omurice (chỉ là vật phẩm ảo).
- **4 avatar starter variants**, các màu/trang phục cơ bản; không bắt buộc account.
- **3 trạng thái nhân vật:** idle, moving, interacting; có trạng thái sit/serve/prepare tùy role.
- **3–5 emotes**: wave, bow, thanks, happy, surprised.
- **Minigame:** chọn đúng thứ tự nguyên liệu trong giới hạn thời gian thoải mái; không trừng phạt người chơi bằng mất quyền truy cập.
- **NPC fallback:** một nhân vật công khai là NPC nhận đơn trễ; không giả là người thật, không auto chat với vẻ như user.
- **Ảnh Cheki:** chỉ ảnh client-rendered với sprite của người đồng ý; không cần lưu server-side trong MVP.

### 1.7 Core user journeys & acceptance

**J1 Guest Customer:** landing → create guest → pick avatar → lobby → join room → seat → order → receive → emote → screenshot. Toàn bộ không yêu cầu tài khoản trả phí.

**J2 Maid:** create guest → choose Maid → join shift → see pending orders → claim → minigame → deliver → get XP → end shift.

**J3 Friends:** A tạo invite link → B mở → nếu room còn chỗ được vào cùng room; hết chỗ trả trạng thái rõ và đề xuất room mới; không bypass quota.

**J4 Safety:** A bị B quấy rối → A mute/block hoặc report → ngay lập tức không nhận chat B nữa → moderator thấy report và xử lý → sanction áp dụng cả sau reconnect.

**J5 Resilience:** A đang phục vụ mất kết nối 10 giây → vào lại trong grace period → thấy room/order/role nhất quán; hết hạn thì order được requeue hoặc NPC fallback theo quy tắc.

### 1.8 KPI đo lường (giả thuyết, chưa phải benchmark)

- Landing → joined-room conversion; session length; first order placed; order completion rate.
- Maid active shift ratio; order wait time p50/p95; NPC fallback rate.
- Day-1/Day-7 return rate; invite conversion; report rate per active users; moderation median response time.
- Server: CCU, room count, socket reconnect, command error rates, event latency, resource usage.
- Analytics chỉ thu dữ liệu tối thiểu, có thông báo minh bạch và khả năng tắt analytics không thiết yếu.

---

