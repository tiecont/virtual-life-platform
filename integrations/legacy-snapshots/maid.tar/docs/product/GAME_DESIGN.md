## 3. DOMAIN MODEL & STATE MACHINES

### 3.1 Entities

- `User` (registered optional later), `GuestSession`, `PlayerProfile`.
- `CafeTemplate`, `Room`, `RoomParticipant`, `Seat`, `ActiveMaidShift`.
- `MenuItem`, `Order`, `OrderEvent`, `PreparationAttempt`.
- `Wallet` (virtual), `RewardLedger`, `OwnedCosmetic`, `PlayerStats`.
- `ChatMessage` (short-lived for reports/moderation), `UserBlock`, `UserMute`, `Report`, `ModerationAction`, `AuditEvent`, `PhotoConsent` (ephemeral).

### 3.2 Room state

`CREATED → OPEN → DRAINING → CLOSED`. Phòng tự tạo khi cần, đóng khi hết người sau TTL. `DRAINING` không nhận người mới, vẫn cho người hiện tại hoàn tất/exit; deploy có deadline để force safe shutdown.

Quy tắc quota: `total <= maxTotal`, `customer <= maxCustomer`, `maid <= maxMaid`. Join phải atomically kiểm tra cả ba. Seat là resource độc lập với participation; có thể ở room nhưng chưa ngồi.

### 3.3 Presence state

`CONNECTED → TEMPORARILY_DISCONNECTED → LEFT/EXPIRED`, `AFK` là user activity flag, không phải disconnect. Grace period đề xuất **30 giây** (config), heartbeat/transport timeout theo Socket.IO. Ngắt kết nối ngắn không tự động phát thưởng hoặc đánh dấu hoàn tất task.

Multi-tab: một `guestSession` có thể có nhiều sockets, nhưng chỉ **một active player instance/room** cho mỗi identity; các tab còn lại ở chế độ spectator hoặc được yêu cầu take-over có xác nhận. Không cho duplicate seat/shift/EXP từ các tab.

### 3.4 Role & shift rules

- `Customer ↔ Maid` chỉ khi không giữ active order/shift cần hoàn tất; có API bàn giao an toàn.
- Maid shift: `OFF_DUTY → ON_DUTY → PAUSED → ENDED`. Auto-end khi leave, nhưng cần giải quyết outstanding orders.
- Customer ordering requires assigned seat; configurable để sau này cho takeaway.
- Maid may claim tối đa 2 `ASSIGNED/PREPARING/READY` orders (config).
- End shift khi còn order: `handoff` trước, hoặc server thực hiện requeue transactionally.

### 3.5 Order state machine — source of truth

```text
PENDING ──claim──> ASSIGNED ──prepare──> PREPARING
   |                  |                       |
   | customer.cancel  | maid.disconnect/TTL   | minigame.complete
   v                  v                       v
CANCELLED           PENDING                 READY
                                               |
                                            deliver
                                               v
                                             SERVED
                                               |
                                           complete
                                               v
                                           COMPLETED
```

- `PENDING → CANCELLED` cho Customer nếu chưa được nhận; sau đó cần cancellation policy rõ và không làm mất trạng thái bất ngờ.
- `ASSIGNED → PENDING` hoặc `PREPARING → PENDING` khi bàn giao; **version increment**; minigame attempt cũ invalid.
- `READY → SERVED` chỉ khi Maid đang sở hữu order và ở interaction point hợp lệ; game logic không tin vị trí client tự báo.
- `SERVED → COMPLETED` server tự hoàn tất sau xác nhận phù hợp; idempotent.
- Order terminal: `CANCELLED`, `COMPLETED`; không resurrect.
- Timeout phải có đường xử lý: requeue hoặc NPC fulfill; khách nhìn thấy thông báo rõ ràng.
- **NPC fallback**: nếu quá `NPC_FALLBACK_MS` mà order pending, `NPC` claim theo cùng state machine, chỉ một winner; có `fulfilledByType = NPC`.

### 3.6 Reward state machine

EXP/reward chỉ được cấp sau order `COMPLETED`, role phù hợp và guard chống abuse. Sử dụng unique `(user_id, source_type, source_id, reward_kind)` trong ledger. Reward/complete nằm trong cùng DB transaction hoặc có idempotent recovery bằng outbox. Không cho client gọi `reward.grant`.

### 3.7 Moderation semantics

- **Mute local:** chỉ ảnh hưởng nội dung hiển thị cho người thực hiện mute.
- **Block:** ngăn chat/targeted interaction và ẩn nội dung; xử lý shared-space bằng đổi bàn/phòng khi cần; tránh lộ block list công khai.
- **Chat timeout:** server từ chối `chat.send`, kể cả khi reconnect/new tab.
- **Kick room:** đóng membership + socket event, không đồng nghĩa account ban.
- **Temporary ban:** chặn HTTP join và realtime join cho identity đã biết đến `expiresAt`.
- **Admin action:** immutable audit có actor, reason, target, timestamp, policy reason; hỗ trợ appeal workflow tối thiểu qua form.
- Không dùng regex blacklist như cơ chế bảo vệ duy nhất; thiết kế rules + reports + manual review. Có hạn mức/retention cho message evidence.

---

## 6. GAME CLIENT & ART SYSTEM

### 6.1 Scene graph

```text
GameShell
 ├── InputController (pointer/touch)
 ├── Camera (zoom/viewport constraints)
 ├── TileMap / Collision / InteractionPoints
 ├── EntityLayer (players, NPCs, props)
 ├── AnimationSystem (idle/walk/sit/prepare/serve/emote)
 ├── PathRenderer (accepted server path)
 ├── InteractionOverlay (hover/click target)
 └── ResponsiveHUD (chat, order, profile, safety)
```

### 6.2 Game art direction

- Anime-inspired **original** chibi pixel art; pastel pink/cream/wood; cozy sakura café; không sao chép nhân vật/biểu tượng thương mại.
- Đồng nhất sprite scale, tile size, lighting, palette, animation FPS, naming conventions và z-order.
- Thiết kế asset pipeline có `manifest.json` chứa size, frames, anchor, hitbox, collision, license/source.
- Mọi external asset phải có license rõ (`CC0`, quyền thương mại, hoặc bản quyền do dự án sở hữu); ghi `assets/LICENSES.md`.
- Audio opt-in, mute by default hoặc theo browser policy; âm lượng riêng; không tự động phát file bản quyền không có phép.
- Placeholder được dùng trong prototype, **không chấp nhận placeholder/stock watermarked trong release**.

### 6.3 Movement implementation

- Click/touch một `interactionPoint` (seat, counter, table, photo spot, lounge).
- Client sends `player.move(targetPointId)`; server checks target in room map, access by role, reasonable cooldown, source position known.
- Server returns accepted path/waypoints + start time, duration or discrete movement rules. All clients animate same path.
- Không tin coordinate x/y arbitrary từ client. Server xác minh range và action context (serve near table, prepare near counter).
- Collision with static map (and optional occupied interaction points). Dynamic crowd collision có thể dùng soft overlap nếu cần; không cố làm pathfinding MMORPG.
- Snapshot sync stores authoritative current target/last update; corrects drift on reconnect.

### 6.4 UI responsiveness & accessibility

- Desktop primary: game canvas 16:9 with responsive resizing/letterboxing.
- Mobile: landscape recommendation hoặc portrait HUD with controls; no tiny clickable surfaces.
- Keyboard accessible menus, visible focus, reduced motion, muted audio, legible text size.
- Text chat with keyboard and screen-reader labels; game canvas có HTML alternative controls cho major actions.
- Không chặn gameplay chính nếu máy yếu; có setting giảm particle/animation.

### 6.5 Snapshot rendering & photo booth

- Renderer xuất PNG cục bộ từ scene/canvas, không tự upload.
- Chỉ hiển thị những người chơi khác trong ảnh Cheki khi họ đã `photo.consent` cho lần chụp hoặc chế độ đồng ý rõ ràng; nếu không, ẩn sprite hoặc dùng silhouette.
- Không render nội dung chat hoặc thông tin account vào ảnh nếu thiếu đồng ý.
- Metadata ảnh có timestamp/room/theme nếu người dùng chọn; không chứa identifiers nhạy cảm.

---


Operational rules: active orders prevent role switches. Leaving a shift requeues assigned/preparing/ready orders and invalidates attempts. Customer departure cancels active orders. Restart cancels nonterminal orders with a recorded recovery reason. Failed preparation permits a new attempt without reward. NPC cannot grant Maid XP.
