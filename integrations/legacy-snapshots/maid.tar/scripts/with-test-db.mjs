import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
const args = process.argv.slice(2);
if (!args.length) throw new Error("Supply a test command");
const project = "maid-cafe-test-" + randomUUID().slice(0, 8);
const run = (command, args, env = process.env) =>
  new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: "inherit", env });
    child.once("error", reject);
    child.once("exit", (code) =>
      code === 0 ? resolve() : reject(new Error(`${command} exited ${code}`)),
    );
  });
const compose = ["compose", "-p", project, "-f", "infra/compose/test.yaml"];
let created = false;
try {
  if (!process.env.TEST_DATABASE_URL) {
    await run("docker", [...compose, "up", "-d", "--wait"]);
    created = true;
    process.env.TEST_DATABASE_URL =
      "postgresql://maid_test:local_test_only@127.0.0.1:55433/maid_cafe_test";
  }
  const name = new URL(process.env.TEST_DATABASE_URL).pathname.slice(1);
  if (!/^maid_cafe_test(?:_|$)/.test(name))
    throw new Error("Refusing non-test database");
  if (args[0] === "playwright") {
    process.env.DATABASE_URL = process.env.TEST_DATABASE_URL;
    await run("pnpm", ["db:migrate"]);
    await run("pnpm", ["db:seed"]);
  }
  await run("pnpm", ["exec", ...args]);
} catch (error) {
  console.error(String(error));
  process.exitCode = 1;
} finally {
  if (created) await run("docker", [...compose, "down", "--volumes"]);
}
