import {spawn,type ChildProcess} from 'node:child_process';
import {isolatedDb} from '../apps/api/test/database';
async function main(){
const children:ChildProcess[]=[];
let closing=false;
const database=await isolatedDb();
async function close(){if(closing)return;closing=true;for(const p of children){if(p.pid)try{process.kill(-p.pid,'SIGTERM');}catch{/* already exited */}}await database.destroy();process.exit(0);}
for(const signal of ['SIGTERM','SIGINT'])process.once(signal,()=>void close());
function run(args:string[],env:NodeJS.ProcessEnv){const p=spawn('pnpm',args,{stdio:'inherit',detached:true,env:{...process.env,...env}});children.push(p);p.once('exit',code=>{if(!closing){console.error('Test server exited',code);void close();}});}
run(['--filter','@deadline/api','exec','tsx','src/main.ts'],{DATABASE_URL:database.url,PORT:'4200',HOST:'127.0.0.1',NODE_ENV:'test',PUBLIC_ORIGIN:'http://localhost:3200'});
run(['--filter','@deadline/web','dev'],{NEXT_DIST_DIR:'.next-e2e',WEB_PORT:'3200',API_INTERNAL_URL:'http://127.0.0.1:4200',NODE_ENV:'development'});
}
void main().catch(error=>{console.error(error);process.exit(1);});
