#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
expected="v$(cat .node-version)"
actual="$(node --version)"
if [ "$actual" != "$expected" ]; then
  echo "Use Node $expected (current $actual). See README.md." >&2
  exit 1
fi
if [ "$(pnpm --version)" != '11.28.5' ]; then
  echo 'Use pnpm 11.28.5.' >&2
  exit 1
fi
