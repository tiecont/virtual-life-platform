# Decisions
- ADR-0001: specified MVP stack; single authoritative Nest/Fastify process, native WebSocket transport, PostgreSQL/Drizzle, Next/React/Pixi.
- Runtime: Node 26.13.0 (active LTS per official Node release schedule checked 2026-11-02), pnpm 11.28.5. Existing host Node 26.9.0 is superseded for verification by a task-local pinned binary.
- Native WS, no Socket.IO. Focus continues when disconnected; completion records elapsed timer only. Break timer is local, 5/10 minutes; presence cannot override active focus.
- Guest lifetime 30 days fixed, no sliding token rotation; create fresh identity after expiry. Deletion purges profile and focus data, closes sockets. Backup expiry follows retention policy.
- Original procedural pixel sprites and scene graphics; no external artwork, music or fonts. Audio initially off, optional synthesized rain only.
- Production deployment, offsite destination, legal contact, owner visual approval, remote CI evidence need owner resources. Local validation remains required.
- 2026-11-02 user design direction: airy, youthful, polished cafe identity inspired by Phê La/Katinat. Inspect public official websites for visual references; original branding/assets, preserve required cozy pixel cafe scene. Light sage/cream DOM shell, amber night scene.
