# Deadline Café: art and interaction direction
User request 2026-11-02: youthful, beautiful, airy cafe design inspired by Phê La and Katinat. References are inspiration only, no copied brand graphics/layouts. Official references: https://phela.vn (web fetch denied 403), https://katinat.vn (public homepage and cafe imagery reviewed). No third-party assets included.

Identity: “Chậm một nhịp. Xong một việc.” Small monogram made from a coffee cup/sun, expressive editorial serif headlines and clean system sans-serif controls, generous cream whitespace, forest/sage green, muted clay accents. Rounded pill CTAs, fine borders, wide gutters, large readable numerals. No dense gamer HUD. Theme distinction: airy daytime DOM shell, warm amber/rainy night original pixel scene.

Palette: cream #f7f5ec, ink #233f35, forest #244c3d, sage #dbe5d5, pale lime #e6eecf, clay #b75c3d. Scene palette walnut #654631, cedar #9a6d46, amber #f4c47c, dark green #183c34, rain blue #26454e.

Landing: quiet editorial top bar; large left headline + invitation, right original drawn cafe illustration marked preview; ribbon containing product truths (no account, real guests, 15/25/50); three understated steps; real room availability section. Lobby retains visual breathing room, simple profile form and room cards. Cafe: clear header, canvas centered, accessible seat drawer and focused DOM timer card. Mobile controls remain outside scrollable scene.

Scene: top-down 3/4, 960×640, wall/window/back counter at top, warm plank floor, 15 paired desk tables/30 distinct seats, plants and pastry shelf. Seat IDs stable seat-01..30, machine checked bounds and uniqueness. Avatar eight handmade 16×20 sprites/palettes; no avatars when no guests. Status ring and text (idle/focus/break/away), subtle blink/steam/rain when motion enabled. Pixi imported only in client component. Semantic HTML seat buttons remain available if renderer fails.

Motion/audio: reduced motion disables animation, manual ambience toggle; sound synthesized locally only after explicit toggle, default off. Scene fit/pan/zoom controls support narrow viewports. Text contrast target 4.5:1 and 44px touch targets; owner review and actual device FPS remain measured acceptance, not a design assertion.
