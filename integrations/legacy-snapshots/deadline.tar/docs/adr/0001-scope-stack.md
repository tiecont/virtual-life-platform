# ADR-0001: MVP scope and architecture
Status: accepted, 2026-11-02
Context: empty repository; authoritative execution plan v1.0.
Decision: retain pnpm, strict TS, Next App Router/React/Tailwind/Zustand/Pixi client-only, Nest/Fastify/native ws, Zod, PostgreSQL/Drizzle. One API replica, 30 seats/40 occupants, no chat/accounts/payments. Durable focus and hashed guest sessions; RAM seat ownership. HTTP/WS same-origin via proxy. DB constraints arbitrate concurrent focus starts. Cookie + Origin + per-session CSRF defend writes.
Consequences: RAM seats reset on restart; focus survives. Horizontal replication prohibited until ADR with fenced room ownership. Asset style is original top-down 3/4 pixel art. Human visual/release approval remains a release gate.
Evidence: https://github.com/nodejs/Release ; https://nodejs.org/en/blog/release/v26.13.0 ; https://nextjs.org/docs/app/getting-started/installation ; https://docs.nestjs.com/migration-guide ; registry engine compatibility also validated at install.
