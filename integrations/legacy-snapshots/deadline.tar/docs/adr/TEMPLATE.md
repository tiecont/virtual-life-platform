# ADR-NNNN: Title
Status / Date
## Context
## Decision
## Alternatives
## Consequences and migration
## Verification
