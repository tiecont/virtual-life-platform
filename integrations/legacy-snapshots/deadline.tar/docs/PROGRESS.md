# Progress
Last updated: 2026-11-02T13:36:38.753634+00:00
Current branch: main
Current phase: P03
Current task: P03-01

## Verified
- [x] P00-01: directory empty, no existing Git repository or ancestor AGENTS.md. `git init -b main` → 0. Source plan located in Downloads, fully read (703 lines).
- [x] P00-02/P00-03: canonical plan, agent contract, decisions, ADR template, PRD/risk register/milestone map created.

## In progress
- [~] P00-04: pin Node 26.13.0 and pnpm 11.28.5. Official release/compatibility checked; package lock verified in P01.

## Blocked
- [!] P10-08: owner domain, VPS, secrets and production deployment authorization absent.
- [!] P11 release sign-off: requires owner product review.

## Validation snapshot
Environment: Linux local development host, initial Node 26.9.0/pnpm 11.28.5, Docker 29.9.0 available; PostgreSQL binaries installed.
`docker info --format '{{.ServerVersion}}'` → 0, 29.9.0.
Application checks: NOT_RUN (repository initially empty).

## Next exact action
P01-01: create workspace and install pinned compatible dependencies, then build and start HTTP/web baseline. Finish P00-04 with frozen lock verification.

## Risks / deviations
No production deployment claimed. No stack deviations.

## Phase P00 checkpoint
Tasks completed: P00-01..04; Pending: none. Files: governance, runtime/workspace pins and lock. Validation: official Node release schedule plus registry engines, pinned Node `v26.13.0`, `pnpm install --frozen-lockfile` → 0. Initial package install → 1 (pnpm 11 legacy onlyBuiltDependencies ignored); corrected to allowBuilds and reinstall → 0. Git: da80985 plus P01 commit. Next: P01 baseline validation (completed below).

## Phase P01 checkpoint
Tasks completed: P01-01..05. Files: apps/web, apps/api, packages/contracts, packages/scene-data, packages/config, infra/compose/dev.yml, scripts/check-runtime.sh, README, env example.
Validation 2026-11-02, Linux Ryzen 7 4800HS, Node 26.13.0/pnpm 11.28.5:
- `pnpm install --frozen-lockfile` → 0, lock policy verified; trusted esbuild/parcel native builds explicitly allowed, Nest optional donation script denied.
- `pnpm check` → 0: lint, strict types, 1 contract + 3 API tests, Next production webpack build and API tsc. Logs: artifacts/p01-check.log (local ignored artifacts). Scene/web have no tests yet; no functionality implied by empty suites.
- After log privacy/exception-filter fix: `pnpm lint && pnpm typecheck && pnpm --filter @deadline/api test && pnpm --filter @deadline/api build` → 0 (3 API tests).
- `docker compose --env-file .env -f infra/compose/dev.yml up -d --wait` → 0, postgres:17.7-alpine healthy.
- `pnpm dev` initially failed EADDRINUSE on existing unrelated :3000; left that service untouched. Restarted using task-local :3100 web/:4100 API, documented overrides. `/healthz` → 200 ok; `/readyz` → 200 ready; unreachable DB test → 503 while liveness 200.
- Request logs now omit client IP/query/cookies and use UUID request IDs; unknown Nest errors get shared safe shape.
Known risks: production release gates remain blocked. Design direction refined by user to airy cream/sage cafe shell, original pixel interior. Next action: P02-01 Drizzle durable schema, migrations and isolated PostgreSQL integration tests.

## Phase P02 checkpoint
Tasks completed: P02-01..05 (code and HTTP/PG verification); no external blockers.
Files: API db schema/generated Drizzle SQL and journal, migration/seed, Guests/Catalog, HTTP boundary, bounded limits, shared profile/public schemas, isolated test DB helper.
Validation 2026-11-02 Node 26.13.0/PostgreSQL 17.7:
- `pnpm db:migrate`, `pnpm db:seed`, repeated `pnpm db:seed` → 0.
- `pnpm lint && pnpm typecheck && pnpm test` → 0 (API config, health, rate-window unit tests; contract schema test).
- `pnpm test:integration` → 0, 5 real HTTP/isolated-PG tests: repeat migrations/seed, distinct identities/reload, hashed tokens/HttpOnly cookie, PATCH allow-list/XSS/reserved-name rejection, Origin/CSRF failures, delete isolation, forged/expired/revoked tokens, purge, room config, oversized body and rate limit.
- Initial typecheck/integration failed on nullable cookie types; fixed before passing run. No tests skipped to hide failures.
Known risks: realtime is not yet mounted; room availability is empty until real room membership is implemented at P05. Expiry purge hourly. No claim of production compliance. Next exact action: P03-01 build airy Vietnamese landing/onboarding/lobby and test real browser guest creation against this backend.

P02 build gate: `pnpm build` → 0 (API tsc, Next 16.4.4 production build). P02 phase commit follows this checkpoint.
