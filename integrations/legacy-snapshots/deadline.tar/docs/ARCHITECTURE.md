# Architecture
Browser → same origin Next pages, /api/v1 REST and /socket native WS → Nest/Fastify (one replica) → PostgreSQL.
- contracts owns Zod boundaries and public types; scene-data owns stable seat IDs/coordinates and eight original palette variants.
- web owns DOM flows and client-only Pixi rendering; no server secrets or guest cookie access in JavaScript.
- API owns authenticated guest identity, RAM rooms/seats, presence, DB focus lifecycle and stats. Never run multiple API replicas.
- PostgreSQL is authoritative for sessions and focus. Seat RAM resets after process restart; reconnect receives explicit fresh state.
- Health: /healthz alive; /readyz DB query; /metrics private bearer-protected. Backpressure limits and 8KiB frames bound sockets.
- No transport swaps or external analytics. Cookies HttpOnly/SameSite=Lax, production Secure, fixed 30-day lifetime. CSRF HMAC is session-specific, distinct from cookie secret.
