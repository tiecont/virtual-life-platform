# Asset provenance ledger
All shipped visual assets are original and generated deterministically from repository source; no Phê La/Katinat logos, photos, music, typography or UI assets are distributed. Brand websites are visual references only. System fonts are used; no font binaries are shipped.

| Path | Origin / creator | Source | License / rights | Attribution | Proof/date |
|---|---|---|---|---|---|
| apps/web/public/assets/cafe-postcard.svg | Original vector drawing authored in this repository | SVG source / git | Original project work; available to project owner for distribution | No external attribution | 2026-11-02 P03 commit |
| apps/web/src/components/Brand.tsx (CupMark) | Original cup line drawing | inline SVG source / git | Original project work | None | 2026-11-02 |
| apps/web/app/globals.css (avatars/room cover) | Original procedural CSS shapes and palette | repository source | Original project work | None | 2026-11-02 |

Reference links: https://phela.vn (403 when directly fetched); https://katinat.vn/ and https://mba.katinat.vn/ (public visual references, not asset sources). Human owner review of visual quality is still required for release.
