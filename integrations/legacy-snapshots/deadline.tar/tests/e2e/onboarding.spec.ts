import {test,expect} from '@playwright/test';
test('real guest onboarding, reload persistence and invited room',async({page})=>{
 await page.goto('/');await expect(page.getByRole('heading',{name:'Chậm một nhịp. Xong một việc.'})).toBeVisible();
 await page.getByRole('link',{name:'Tìm một chỗ cho mình'}).click();await page.getByLabel('Tên ở quán').fill('Linh kiểm thử');await page.getByRole('button',{name:'Avatar 3',exact:true}).click();await page.getByRole('button',{name:'Mình sẵn sàng rồi'}).click();
 await expect(page.getByRole('heading',{name:'Linh kiểm thử',exact:true})).toBeVisible();
 await page.reload();await expect(page.getByRole('heading',{name:'Linh kiểm thử',exact:true})).toBeVisible();
 await page.getByRole('link',{name:'Vào ngồi'}).first().click();await expect(page).toHaveURL(/\/cafe\/dem-la-01/);await expect(page.getByRole('heading',{name:'Một góc của mình.'})).toBeVisible();await page.reload();await expect(page.getByRole('heading',{name:'Một góc của mình.'})).toBeVisible();
 const cookies=await page.context().cookies();const session=cookies.find(c=>c.name==='deadline_session');expect(session?.httpOnly).toBe(true);
 expect(await page.evaluate(()=>Object.values(localStorage).join(''))).not.toContain(session!.value);
});
test('unknown room and route have useful recovery',async({page})=>{await page.goto('/cafe/not-real');await expect(page.getByRole('heading',{name:'Góc này chưa mở cửa.'})).toBeVisible();await page.getByRole('link',{name:'Tìm một phòng khác'}).click();await expect(page).toHaveURL('/lobby');await page.goto('/not-a-page');await expect(page.getByRole('link',{name:'Về sảnh'})).toBeVisible();});
