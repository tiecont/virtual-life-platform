import {describe,it,expect} from 'vitest';
import {errorSchema} from './index';
describe('HTTP error contract',()=>{
 it('requires a traceable error code and message',()=>{
  expect(errorSchema.safeParse({message:'unavailable'}).success).toBe(false);
  expect(errorSchema.parse({code:'UNAVAILABLE',message:'Retry later',requestId:'r-1'}).code).toBe('UNAVAILABLE');
 });
});
