export const SCENE = { width:960, height:640 };
export const seats = Array.from({length:30}, (_,i)=>({id:`seat-${String(i+1).padStart(2,'0')}`,x:110+(i%6)*144,y:190+Math.floor(i/6)*82}));
export const avatarKeys = ['fern','amber','indigo','rose','cloud','cocoa','mint','plum'] as const;
