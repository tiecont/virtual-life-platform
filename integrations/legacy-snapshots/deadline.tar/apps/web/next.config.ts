import type { NextConfig } from 'next';
const config:NextConfig={devIndicators:false,distDir:process.env.NEXT_DIST_DIR||'.next',transpilePackages:['@deadline/contracts','@deadline/scene-data'],output:'standalone', async rewrites(){const api=process.env.API_INTERNAL_URL||'http://127.0.0.1:4000';return [{source:'/api/v1/:path*',destination:`${api}/api/v1/:path*`},{source:'/healthz',destination:`${api}/healthz`}];}};
export default config;
