import Lobby from '../../src/components/Lobby';
export default function Page(){return <Lobby/>;}
