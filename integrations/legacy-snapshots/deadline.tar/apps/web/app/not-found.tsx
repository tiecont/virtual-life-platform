import Link from 'next/link';
export default function NotFound(){return <main className="prose"><span className="eyebrow">404 · LẠC MỘT CHÚT THÔI</span><h1>Con đường này<br/>chưa dẫn tới quán.</h1><Link href="/lobby" className="button">Về sảnh →</Link></main>;}
