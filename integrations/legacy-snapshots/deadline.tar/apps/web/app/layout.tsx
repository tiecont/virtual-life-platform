import './globals.css';
import {Header,Footer} from '../src/components/Brand';
import type { Metadata } from 'next';
export const metadata:Metadata={title:'Deadline Café · Cùng nhau tập trung',description:'Quán cà phê làm việc chung: chọn chỗ, tập trung, không cần tài khoản.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="vi" data-scroll-behavior="smooth"><body><a className="skip-link" href="#main-content">Bỏ qua đến nội dung</a><Header/><div id="main-content">{children}</div><Footer/></body></html>;}
