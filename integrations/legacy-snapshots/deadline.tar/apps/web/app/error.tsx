'use client';
export default function ErrorPage({reset}:{reset:()=>void}){return <main className="prose"><h1>Quán gặp chút trục trặc.</h1><p role="alert">Bạn thử mở lại góc này nhé.</p><button className="button" onClick={reset}>Thử lại</button></main>;}
