export default function Loading(){return <main className="prose" role="status">Đang pha một chút bình yên…</main>;}
