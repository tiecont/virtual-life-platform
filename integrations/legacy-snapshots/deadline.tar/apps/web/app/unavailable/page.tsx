import Link from 'next/link';
export default function Page(){return <main className="prose"><span className="eyebrow">QUÁN TẠM NGHỈ</span><h1>Đợi một tách trà nhé.</h1><p>Dịch vụ hiện chưa kết nối được. Phiên focus đã lưu sẽ đồng bộ lại khi quán mở cửa.</p><Link href="/lobby" className="button">Thử kết nối lại →</Link></main>;}
