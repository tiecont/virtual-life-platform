import Link from 'next/link';
export default function Stats(){return <main className="prose"><span className="eyebrow">GÓC CỦA BẠN</span><h1>Mỗi chút cố gắng<br/>đều xứng đáng.</h1><p>Thống kê sẽ xuất hiện khi phiên focus được server xác nhận. Quán chưa có dữ liệu thành tích để hiển thị.</p><Link href="/lobby" className="button">Ghé quán →</Link></main>;}
