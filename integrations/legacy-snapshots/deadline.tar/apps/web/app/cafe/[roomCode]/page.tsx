import CafeShell from '../../../src/components/CafeShell';
export default async function Page({params}:{params:Promise<{roomCode:string}>}){const {roomCode}=await params;return <CafeShell code={roomCode}/>;}
