'use client';
import {useState,useEffect} from 'react';
import Link from 'next/link';
import type {PublicRoom,Profile} from '@deadline/contracts';
import {getMe,api,RequestError} from '../features/api';
import {useGuest} from '../features/store';
import {GuestSetup} from './GuestSetup';
import FocusPanel from './FocusPanel';
export default function CafeShell({code}:{code:string}){
 const [room,setRoom]=useState<PublicRoom|null>(null);const [guest,setGuest]=useState<Profile|null>(null);const [loading,setLoading]=useState(true);const [error,setError]=useState('');
 useEffect(()=>{let active=true;void Promise.all([api<PublicRoom>('/rooms/'+encodeURIComponent(code)),getMe().catch(e=>{if(e instanceof RequestError&&e.status===401)return null;throw e;})]).then(([r,p])=>{if(active){setRoom(r);setGuest(p);useGuest.getState().setProfile(p);}}).catch(e=>{if(active)setError(e.message);}).finally(()=>{if(active)setLoading(false);});return()=>{active=false;};},[code]);
 if(loading)return <main role="status">Đang mở cửa quán…</main>;
 if(error||!room)return <main><h1>Góc này chưa mở cửa.</h1><p role="alert">{error||'Phòng không tồn tại'}</p><Link href="/lobby" className="button">Tìm một phòng khác</Link></main>;
 if(!guest)return <main className="setup-main"><GuestSetup onReady={setGuest}/></main>;
 return <main><div className="cafe-heading"><div><span className="eyebrow">ĐÊM LÁ / {room.publicCode}</span><h1>Một góc của mình.</h1></div><Link href="/lobby" className="text-link">← Về sảnh</Link></div><div className="cafe-grid"><section className="scene-placeholder"><h2>Không gian Đêm Lá</h2><p>Phòng đã sẵn sàng. Kết nối chỗ ngồi đang được hoàn thiện.</p><p>Chưa hiển thị người trực tuyến khi chưa có snapshot.</p></section><FocusPanel/></div></main>;
}
