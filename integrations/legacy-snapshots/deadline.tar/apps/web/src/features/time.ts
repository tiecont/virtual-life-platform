export function remainingSeconds(endsAt:string|null,now=Date.now(),skew=0){return endsAt?Math.max(0,Math.ceil((new Date(endsAt).getTime()-now-skew)/1000)):0;}
export function formatTime(seconds:number){return `${Math.floor(seconds/60).toString().padStart(2,'0')}:${(seconds%60).toString().padStart(2,'0')}`;}
