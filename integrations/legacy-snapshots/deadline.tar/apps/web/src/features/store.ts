import {create} from 'zustand';
import type {Profile} from '@deadline/contracts';
// Only public profile + CSRF are held in memory. The session cookie is HttpOnly.
export const useGuest=create<{profile:Profile|null;setProfile:(p:Profile|null)=>void}>((set)=>({profile:null,setProfile:profile=>set({profile})}));
