import type {Profile,PublicRoom,PublicCafe} from '@deadline/contracts';
export class RequestError extends Error{constructor(public code:string,message:string,public status:number){super(message);}}
export async function api<T>(path:string,options:RequestInit={},csrf?:string):Promise<T>{
 const response=await fetch('/api/v1'+path,{...options,credentials:'same-origin',cache:'no-store',headers:{...(options.body?{'content-type':'application/json'}:{}),...(csrf?{'x-csrf-token':csrf}:{}),...options.headers}});
 const body=await response.json().catch(()=>({code:'UNAVAILABLE',message:'Quán tạm mất kết nối. Bạn thử lại nhé.'}));
 if(!response.ok)throw new RequestError(body.code||'UNAVAILABLE',body.message||'Không thể kết nối',response.status);
 return body as T;
}
export const getMe=()=>api<Profile>('/me');
export const getRooms=()=>api<PublicRoom[]>('/cafes/dem-la/rooms');
export const getCafes=()=>api<PublicCafe[]>('/cafes');
