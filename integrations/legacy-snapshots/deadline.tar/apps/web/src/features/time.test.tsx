import {describe,it,expect} from 'vitest';
import {renderToStaticMarkup} from 'react-dom/server';
import {remainingSeconds,formatTime} from './time';
import {Avatar} from '../components/GuestSetup';
describe('timer display',()=>{it('uses canonical deadline rather than counting ticks',()=>{expect(remainingSeconds('2026-11-02T12:00:30Z',Date.parse('2026-11-02T12:00:00Z'),5000)).toBe(25);expect(remainingSeconds('2026-11-02T12:00:30Z',Date.parse('2026-11-02T12:01:00Z'))).toBe(0);expect(formatTime(1500)).toBe('25:00');});it('renders an original avatar without exposing identity',()=>{const html=renderToStaticMarkup(<Avatar avatarKey="fern"/>);expect(html).toContain('avatar-fern');expect(html).toContain('aria-hidden="true"');});});
