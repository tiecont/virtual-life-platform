import { createApp } from './app';
async function main(){const service=await createApp();await service.app.listen(service.env.PORT,service.env.HOST);for(const signal of ['SIGTERM','SIGINT'])process.once(signal,()=>{void service.close().then(()=>process.exit(0));});}
void main().catch(()=>{console.error(JSON.stringify({level:'error',message:'API startup failed; check environment and database availability'}));process.exit(1);});
