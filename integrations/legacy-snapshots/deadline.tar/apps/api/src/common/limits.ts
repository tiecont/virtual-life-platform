// Fixed windows are bounded in size and expire; no raw IP is logged or exposed.
export class RateLimits{
 private buckets=new Map<string,{count:number;until:number}>();
 constructor(private now=Date.now,private maxKeys=10000){}
 take(key:string,limit:number,windowMs:number){
  const now=this.now();let b=this.buckets.get(key);
  if(!b||b.until<=now){
   if(this.buckets.size>=this.maxKeys){for(const [k,v]of this.buckets)if(v.until<=now)this.buckets.delete(k);if(this.buckets.size>=this.maxKeys)return false;}
   b={count:0,until:now+windowMs};this.buckets.set(key,b);
  }
  return ++b.count<=limit;
 }
 get size(){return this.buckets.size;}
}
