import { z } from 'zod';
export const envSchema = z.object({NODE_ENV:z.enum(['development','test','production']).default('development'),HOST:z.string().default('127.0.0.1'),PORT:z.coerce.number().int().min(1).max(65535).default(4000),DATABASE_URL:z.string().url(),PUBLIC_ORIGIN:z.string().url().default('http://localhost:3000'),METRICS_TOKEN:z.string().min(32).optional()});
export const config = ()=>envSchema.parse(process.env);
