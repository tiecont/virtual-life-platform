import {randomBytes,createHash,timingSafeEqual} from 'node:crypto';
import {and,eq,gt,isNull,lt} from 'drizzle-orm';
import type {Database} from '../db/client';
import {guests,type Guest} from '../db/schema';
import {DomainError} from '../common/errors';
export const COOKIE='deadline_session';
export const hashToken=(token:string)=>createHash('sha256').update(token).digest('hex');
export const csrfFor=(token:string)=>createHash('sha256').update('deadline-csrf-v1:'+token).digest('hex');
export function validCsrf(token:string,header:unknown){const expected=csrfFor(token);return typeof header==='string'&&header.length===expected.length&&timingSafeEqual(Buffer.from(header),Buffer.from(expected));}
export class Guests{
 onDeleted:(id:string)=>void=()=>{};
 onUpdated:(guest:Guest)=>void=()=>{};
 constructor(private db:Database,private now=Date.now){}
 async find(token:unknown){
  if(typeof token!=='string'||!/^[-\w]{43}$/.test(token))return null;
  const [guest]=await this.db.select().from(guests).where(and(eq(guests.tokenHash,hashToken(token)),gt(guests.expiresAt,new Date(this.now())),isNull(guests.revokedAt),isNull(guests.deletedAt)));
  return guest||null;
 }
 async require(token:unknown){const guest=await this.find(token);if(!guest)throw new DomainError('UNAUTHORIZED','Guest session expired. Please enter again.',401);return guest;}
 async create(input:{displayName:string;avatarKey:string}){
  const token=randomBytes(32).toString('base64url');
  const [guest]=await this.db.insert(guests).values({...input,tokenHash:hashToken(token),expiresAt:new Date(this.now()+30*86400000)}).returning();
  return {guest,token};
 }
 public(guest:Guest,token:string){return {id:guest.id,displayName:guest.displayName,avatarKey:guest.avatarKey,expiresAt:guest.expiresAt.toISOString(),csrfToken:csrfFor(token)};}
 async update(id:string,input:{displayName?:string;avatarKey?:string}){const [guest]=await this.db.update(guests).set({...input,lastSeenAt:new Date(this.now())}).where(eq(guests.id,id)).returning();if(!guest)throw new DomainError('UNAUTHORIZED','Guest no longer exists',401);this.onUpdated(guest);return guest;}
 async delete(id:string){await this.db.delete(guests).where(eq(guests.id,id));this.onDeleted(id);}
 async purge(){const removed=await this.db.delete(guests).where(lt(guests.expiresAt,new Date(this.now()))).returning({id:guests.id});for(const g of removed)this.onDeleted(g.id);return removed.length;}
}
