import {and,eq,or} from 'drizzle-orm';
import type {Database} from '../db/client';
import {cafes,rooms} from '../db/schema';
import {DomainError} from '../common/errors';
export class Catalog{
 // Realtime owner supplies counts once mounted; before WS exists no room has joined guests.
 occupancy:(roomId:string)=>{participants:number;seats:number}=()=>({participants:0,seats:0});
 constructor(readonly db:Database){}
 async listCafes(){const list=await this.db.select().from(cafes).where(eq(cafes.enabled,true));const all=await this.db.select().from(rooms).where(eq(rooms.active,true));return list.map(c=>({id:c.id,slug:c.slug,name:c.name,themeKey:c.themeKey,occupancy:all.filter(r=>r.cafeId===c.id).reduce((n,r)=>n+this.occupancy(r.id).participants,0)}));}
 async listRooms(slug:string){const [cafe]=await this.db.select().from(cafes).where(and(eq(cafes.slug,slug),eq(cafes.enabled,true)));if(!cafe)throw new DomainError('NOT_FOUND','Cafe not found',404);return (await this.db.select().from(rooms).where(and(eq(rooms.cafeId,cafe.id),eq(rooms.active,true)))).map(r=>this.public(r));}
 async get(id:string){const [room]=await this.db.select().from(rooms).where(and(eq(rooms.active,true),or(eq(rooms.publicCode,id),...(/^[0-9a-f-]{36}$/i.test(id)?[eq(rooms.id,id)]:[]))));if(!room)throw new DomainError('NOT_FOUND','Room not found',404);return room;}
 public(room:typeof rooms.$inferSelect){const count=this.occupancy(room.id);return {id:room.id,cafeId:room.cafeId,publicCode:room.publicCode,capacity:room.capacity,seatCapacity:room.seatCapacity,occupancy:count.participants,claimedSeats:count.seats};}
}
