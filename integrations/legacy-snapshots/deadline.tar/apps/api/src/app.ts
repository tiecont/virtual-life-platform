import 'reflect-metadata';
import { Module, Controller, Get, Catch, ExceptionFilter, ArgumentsHost, HttpException } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { FastifyAdapter, NestFastifyApplication } from '@nestjs/platform-fastify';
import { Pool } from 'pg';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { randomUUID } from 'node:crypto';
import { config } from './config';
import { database } from './db/client';
import { Guests } from './modules/guests';
import { Catalog } from './modules/catalog';
import { registerHttp } from './http';
@Catch()
class HttpErrors implements ExceptionFilter {
 catch(error:unknown,host:ArgumentsHost){
  const ctx=host.switchToHttp();const req=ctx.getRequest<FastifyRequest>();const reply=ctx.getResponse<FastifyReply>();
  const status=error instanceof HttpException?error.getStatus():500;
  reply.code(status).send({code:status===404?'NOT_FOUND':'INTERNAL_ERROR',message:status===404?'Route not found':'Service temporarily unavailable',requestId:req.id});
 }
}
@Controller()
class HealthController {
 @Get('/healthz') health(){return {status:'ok'};}
}
@Module({controllers:[HealthController]})
class AppModule {}
export async function createApp(options:{now?:()=>number;logging?:boolean}={}){
 const env=config();
 const pool=new Pool({connectionString:env.DATABASE_URL,max:10,connectionTimeoutMillis:2000});
 const app=await NestFactory.create<NestFastifyApplication>(AppModule,new FastifyAdapter({bodyLimit:8192,genReqId:()=>randomUUID(),logger:options.logging===false?false:{level:'info',serializers:{req:(req:FastifyRequest)=>({method:req.method,url:req.url.split('?')[0]})},redact:['req.headers.cookie','req.headers.authorization','req.headers.x-csrf-token','res.headers.set-cookie']}}),{logger:false});
 const http=app.getHttpAdapter().getInstance() as FastifyInstance;
 const db=database(pool);const guests=new Guests(db,options.now);const catalog=new Catalog(db);
 registerHttp(http,guests,catalog,env);
 http.addHook('onSend',async(req,reply)=>{reply.header('x-request-id',req.id);reply.header('x-content-type-options','nosniff');reply.header('referrer-policy','same-origin');reply.header('cache-control','no-store');});
 http.get('/readyz', async (_req,reply)=>{try{await pool.query('select 1');return {status:'ready'};}catch{return reply.code(503).send({status:'unavailable'});}});
 app.useGlobalFilters(new HttpErrors());
 await app.init();
 const purge=setInterval(()=>void guests.purge().catch(()=>http.log.error({code:'PURGE_FAILED'},'Guest expiry purge failed')),3600000);purge.unref();
 return {app,pool,db,guests,catalog,env,close:async()=>{clearInterval(purge);await app.close();await pool.end();}};
}
