import {drizzle} from 'drizzle-orm/node-postgres';
import type {Pool} from 'pg';
import * as schema from './schema';
export const database=(pool:Pool)=>drizzle(pool,{schema});
export type Database=ReturnType<typeof database>;
