import {Pool} from 'pg';
import {migrate} from 'drizzle-orm/node-postgres/migrator';
import {resolve} from 'node:path';
import {database} from './client';
export async function migrateDb(pool:Pool){
 const client=await pool.connect();
 try{
  await client.query('select pg_advisory_lock(9193401)');
  await migrate(database(pool),{migrationsFolder:resolve(__dirname,'../../drizzle')});
 }finally{await client.query('select pg_advisory_unlock(9193401)');client.release();}
}
if(require.main===module){const pool=new Pool({connectionString:process.env.DATABASE_URL});void migrateDb(pool).then(()=>console.log('Migrations applied')).finally(()=>pool.end());}
