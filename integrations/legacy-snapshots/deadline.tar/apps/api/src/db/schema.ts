import {pgTable,pgEnum,uuid,text,timestamp,integer,boolean,uniqueIndex,index,check} from 'drizzle-orm/pg-core';
import {sql} from 'drizzle-orm';
export const guests=pgTable('guest_sessions',{
 id:uuid().primaryKey().defaultRandom(), tokenHash:text('token_hash').notNull().unique(), displayName:text('display_name').notNull(),avatarKey:text('avatar_key').notNull(),
 createdAt:timestamp('created_at',{withTimezone:true}).notNull().defaultNow(),lastSeenAt:timestamp('last_seen_at',{withTimezone:true}).notNull().defaultNow(),expiresAt:timestamp('expires_at',{withTimezone:true}).notNull(),revokedAt:timestamp('revoked_at',{withTimezone:true}),deletedAt:timestamp('deleted_at',{withTimezone:true}),
},t=>[index('guests_expiry_idx').on(t.expiresAt)]);
export const cafes=pgTable('cafes',{
 id:uuid().primaryKey().defaultRandom(),slug:text().notNull().unique(),name:text().notNull(),themeKey:text('theme_key').notNull(),enabled:boolean().notNull().default(true),createdAt:timestamp('created_at',{withTimezone:true}).notNull().defaultNow(),
});
export const rooms=pgTable('rooms',{
 id:uuid().primaryKey().defaultRandom(),cafeId:uuid('cafe_id').notNull().references(()=>cafes.id),publicCode:text('public_code').notNull().unique(),capacity:integer().notNull().default(40),seatCapacity:integer('seat_capacity').notNull().default(30),active:boolean().notNull().default(true),createdAt:timestamp('created_at',{withTimezone:true}).notNull().defaultNow(),
},t=>[check('room_capacity',sql`${t.capacity} between 1 and 40 and ${t.seatCapacity}=30`)]);
export const focusStatus=pgEnum('focus_status',['active','completed','cancelled']);
export const focusSessions=pgTable('focus_sessions',{
 id:uuid().primaryKey().defaultRandom(),guestSessionId:uuid('guest_session_id').notNull().references(()=>guests.id,{onDelete:'cascade'}),roomId:uuid('room_id').notNull().references(()=>rooms.id),durationSeconds:integer('duration_seconds').notNull(),startedAt:timestamp('started_at',{withTimezone:true}).notNull(),endsAt:timestamp('ends_at',{withTimezone:true}).notNull(),completedAt:timestamp('completed_at',{withTimezone:true}),cancelledAt:timestamp('cancelled_at',{withTimezone:true}),status:focusStatus().notNull().default('active'),idempotencyKey:uuid('idempotency_key').notNull(),
},t=>[uniqueIndex('focus_guest_idempotency').on(t.guestSessionId,t.idempotencyKey),uniqueIndex('focus_one_active_guest').on(t.guestSessionId).where(sql`${t.status}='active'`),index('focus_guest_started').on(t.guestSessionId,t.startedAt),index('focus_deadline').on(t.endsAt).where(sql`${t.status}='active'`),check('focus_duration',sql`${t.durationSeconds} in (900,1500,3000)`),check('focus_timestamps',sql`${t.endsAt} > ${t.startedAt}`)]);
export type Guest=typeof guests.$inferSelect;
export type Room=typeof rooms.$inferSelect;
