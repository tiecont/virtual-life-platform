import {Pool} from 'pg';
import {database,type Database} from './client';
import {cafes,rooms} from './schema';
export async function seed(db:Database){
 const [cafe]=await db.insert(cafes).values({slug:'dem-la',name:'Đêm Lá',themeKey:'night-garden'}).onConflictDoUpdate({target:cafes.slug,set:{name:'Đêm Lá'}}).returning();
 await db.insert(rooms).values({cafeId:cafe.id,publicCode:'dem-la-01',capacity:40,seatCapacity:30}).onConflictDoNothing();
}
if(require.main===module){const pool=new Pool({connectionString:process.env.DATABASE_URL});void seed(database(pool)).then(()=>console.log('Cafe configuration seeded; no guests or focus records')).finally(()=>pool.end());}
