import cookie from '@fastify/cookie';
import {ZodError,z} from 'zod';
import type {FastifyInstance,FastifyRequest} from 'fastify';
import {profileInput,profilePatch} from '@deadline/contracts';
import {Guests,COOKIE,validCsrf} from './modules/guests';
import {Catalog} from './modules/catalog';
import {RateLimits} from './common/limits';
import {DomainError} from './common/errors';
import type {config} from './config';
export function registerHttp(http:FastifyInstance,guests:Guests,catalog:Catalog,env:ReturnType<typeof config>){
 const limits=new RateLimits();
 http.register(cookie);
 http.register(async api=>{
  api.setErrorHandler((error,req,reply)=>{
   const status=error instanceof ZodError?422:error instanceof DomainError?error.status:(typeof error==='object'&&error&&'statusCode' in error&&typeof error.statusCode==='number'?error.statusCode:503);
   reply.code(status).send({code:error instanceof ZodError?'VALIDATION_ERROR':error instanceof DomainError?error.code:status===413?'PAYLOAD_TOO_LARGE':status<500?'BAD_REQUEST':'SERVICE_UNAVAILABLE',message:error instanceof DomainError?error.message:status===422?'Please check the supplied fields':status<500?'Invalid request':'Service temporarily unavailable',requestId:req.id});
  });
  api.addHook('onRequest',async req=>{
   if(!limits.take('http:'+req.ip,300,60000))throw new DomainError('RATE_LIMITED','Too many requests',429);
   if(['POST','PATCH','DELETE','PUT'].includes(req.method)&&req.headers.origin!==env.PUBLIC_ORIGIN)throw new DomainError('ORIGIN_REJECTED','Origin is not allowed',403);
  });
  const identity=(req:FastifyRequest)=>guests.require((req.cookies[COOKIE]??''));
  const protectedWrite=async(req:FastifyRequest)=>{const guest=await identity(req);if(!validCsrf((req.cookies[COOKIE]??''),req.headers['x-csrf-token']))throw new DomainError('CSRF_REJECTED','Invalid CSRF token',403);return guest;};
  api.post('/guests/session',async(req,reply)=>{
   if(!limits.take('bootstrap:'+req.ip,12,60000))throw new DomainError('RATE_LIMITED','Please wait before creating another guest',429);
   const existing=await guests.find((req.cookies[COOKIE]??''));
   if(existing)return guests.public(existing,(req.cookies[COOKIE]??''));
   const input=profileInput.parse(req.body);
   const {guest,token}=await guests.create(input);
   reply.setCookie(COOKIE,token,{path:'/',httpOnly:true,secure:env.NODE_ENV==='production',sameSite:'lax',maxAge:30*86400});
   reply.code(201);return guests.public(guest,token);
  });
  api.get('/me',async req=>guests.public(await identity(req),(req.cookies[COOKIE]??'')));
  api.patch('/me',async req=>{const guest=await protectedWrite(req);return guests.public(await guests.update(guest.id,profilePatch.parse(req.body)),(req.cookies[COOKIE]??''));});
  api.delete('/me',async(req,reply)=>{const guest=await protectedWrite(req);await guests.delete(guest.id);reply.clearCookie(COOKIE,{path:'/'});return {deleted:true};});
  api.get('/cafes',()=>catalog.listCafes());
  api.get('/cafes/:slug/rooms',req=>catalog.listRooms(z.object({slug:z.string().min(1).max(64)}).parse(req.params).slug));
  api.get('/rooms/:id',async req=>catalog.public(await catalog.get(z.object({id:z.string().min(1).max(64)}).parse(req.params).id)));
 },{prefix:'/api/v1'});
 return limits;
}
