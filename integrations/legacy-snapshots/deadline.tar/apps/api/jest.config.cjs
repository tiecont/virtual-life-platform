module.exports={testEnvironment:'node',testMatch:['**/test/**/*.spec.ts'],transform:{'^.+\\.tsx?$':['ts-jest',{tsconfig:{...require('./tsconfig.json').compilerOptions,rootDir:'.'}}]}};
