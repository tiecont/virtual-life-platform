CREATE TYPE "public"."focus_status" AS ENUM('active', 'completed', 'cancelled');--> statement-breakpoint
CREATE TABLE "cafes" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"slug" text NOT NULL,
	"name" text NOT NULL,
	"theme_key" text NOT NULL,
	"enabled" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "cafes_slug_unique" UNIQUE("slug")
);
--> statement-breakpoint
CREATE TABLE "focus_sessions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"guest_session_id" uuid NOT NULL,
	"room_id" uuid NOT NULL,
	"duration_seconds" integer NOT NULL,
	"started_at" timestamp with time zone NOT NULL,
	"ends_at" timestamp with time zone NOT NULL,
	"completed_at" timestamp with time zone,
	"cancelled_at" timestamp with time zone,
	"status" "focus_status" DEFAULT 'active' NOT NULL,
	"idempotency_key" uuid NOT NULL,
	CONSTRAINT "focus_duration" CHECK ("focus_sessions"."duration_seconds" in (900,1500,3000)),
	CONSTRAINT "focus_timestamps" CHECK ("focus_sessions"."ends_at" > "focus_sessions"."started_at")
);
--> statement-breakpoint
CREATE TABLE "guest_sessions" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"token_hash" text NOT NULL,
	"display_name" text NOT NULL,
	"avatar_key" text NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	"last_seen_at" timestamp with time zone DEFAULT now() NOT NULL,
	"expires_at" timestamp with time zone NOT NULL,
	"revoked_at" timestamp with time zone,
	"deleted_at" timestamp with time zone,
	CONSTRAINT "guest_sessions_token_hash_unique" UNIQUE("token_hash")
);
--> statement-breakpoint
CREATE TABLE "rooms" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"cafe_id" uuid NOT NULL,
	"public_code" text NOT NULL,
	"capacity" integer DEFAULT 40 NOT NULL,
	"seat_capacity" integer DEFAULT 30 NOT NULL,
	"active" boolean DEFAULT true NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL,
	CONSTRAINT "rooms_public_code_unique" UNIQUE("public_code"),
	CONSTRAINT "room_capacity" CHECK ("rooms"."capacity" between 1 and 40 and "rooms"."seat_capacity"=30)
);
--> statement-breakpoint
ALTER TABLE "focus_sessions" ADD CONSTRAINT "focus_sessions_guest_session_id_guest_sessions_id_fk" FOREIGN KEY ("guest_session_id") REFERENCES "public"."guest_sessions"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "focus_sessions" ADD CONSTRAINT "focus_sessions_room_id_rooms_id_fk" FOREIGN KEY ("room_id") REFERENCES "public"."rooms"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "rooms" ADD CONSTRAINT "rooms_cafe_id_cafes_id_fk" FOREIGN KEY ("cafe_id") REFERENCES "public"."cafes"("id") ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "focus_guest_idempotency" ON "focus_sessions" USING btree ("guest_session_id","idempotency_key");--> statement-breakpoint
CREATE UNIQUE INDEX "focus_one_active_guest" ON "focus_sessions" USING btree ("guest_session_id") WHERE "focus_sessions"."status"='active';--> statement-breakpoint
CREATE INDEX "focus_guest_started" ON "focus_sessions" USING btree ("guest_session_id","started_at");--> statement-breakpoint
CREATE INDEX "focus_deadline" ON "focus_sessions" USING btree ("ends_at") WHERE "focus_sessions"."status"='active';--> statement-breakpoint
CREATE INDEX "guests_expiry_idx" ON "guest_sessions" USING btree ("expires_at");