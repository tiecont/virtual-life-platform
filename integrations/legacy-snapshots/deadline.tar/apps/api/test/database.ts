import {Pool} from 'pg';
import {randomUUID} from 'node:crypto';
import {migrateDb} from '../src/db/migrate';
import {database} from '../src/db/client';
import {seed} from '../src/db/seed';
export async function isolatedDb(){
 if(!process.env.DATABASE_URL)throw new Error('Export a LOCAL development DATABASE_URL with CREATEDB privilege; tests always create a separate database. Never use production credentials.');
 const base=new URL(process.env.DATABASE_URL);base.pathname='/postgres';
 const admin=new Pool({connectionString:base.toString()});const name='deadline_test_'+randomUUID().replace(/-/g,'');
 await admin.query(`CREATE DATABASE "${name}"`);
 base.pathname='/'+name;const url=base.toString();const pool=new Pool({connectionString:url});
 try{await migrateDb(pool);await seed(database(pool));}catch(error){await pool.end();await admin.query(`DROP DATABASE "${name}" WITH (FORCE)`);await admin.end();throw error;}
 return {url,pool,db:database(pool),destroy:async()=>{await pool.end();await admin.query(`DROP DATABASE "${name}" WITH (FORCE)`);await admin.end();}};
}
