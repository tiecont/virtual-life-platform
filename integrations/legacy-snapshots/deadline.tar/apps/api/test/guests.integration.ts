import {createApp} from '../src/app';
import {isolatedDb} from './database';
import {guests,cafes,rooms} from '../src/db/schema';
import {eq} from 'drizzle-orm';
import {seed} from '../src/db/seed';
import {migrateDb} from '../src/db/migrate';
import {COOKIE,hashToken} from '../src/modules/guests';
let service:Awaited<ReturnType<typeof createApp>>;
let database:Awaited<ReturnType<typeof isolatedDb>>;
let base:string;
const origin='http://localhost:3100';
async function request(path:string,method='GET',body?:unknown,cookie?:string,csrf?:string,requestOrigin=origin){return fetch(base+'/api/v1'+path,{method,headers:{origin:requestOrigin,...(body?{'content-type':'application/json'}:{}),...(cookie?{cookie}:{}),...(csrf?{'x-csrf-token':csrf}:{})},...(body?{body:JSON.stringify(body)}:{})});}
beforeAll(async()=>{database=await isolatedDb();process.env.DATABASE_URL=database.url;process.env.PUBLIC_ORIGIN=origin;service=await createApp({logging:false});await service.app.listen(0,'127.0.0.1');base=await service.app.getUrl();});
afterAll(async()=>{await service?.close();await database?.destroy();});
describe('real HTTP and PostgreSQL guest lifecycle',()=>{
 it('migrates and seeds idempotently without fake people',async()=>{await migrateDb(database.pool);await seed(database.db);expect(await database.db.select().from(cafes)).toHaveLength(1);expect(await database.db.select().from(rooms)).toHaveLength(1);expect(await database.db.select().from(guests)).toHaveLength(0);});
 it('sets HttpOnly cookie, hashes token, restores and isolates guests',async()=>{
  const first=await request('/guests/session','POST',{displayName:'  Lan  Anh ',avatarKey:'fern'});expect(first.status).toBe(201);const a=await first.json();expect(a.displayName).toBe('Lan Anh');
  const setCookie=first.headers.get('set-cookie')!;expect(setCookie).toMatch(/HttpOnly/i);expect(setCookie).toMatch(/SameSite=Lax/i);expect(setCookie).toMatch(/Path=\//);const cookie=setCookie.split(';')[0];
  const token=cookie.slice((COOKIE+'=').length);const [stored]=await database.db.select().from(guests).where(eq(guests.id,a.id));expect(stored.tokenHash).toBe(hashToken(token));expect(JSON.stringify(stored)).not.toContain(token);expect(JSON.stringify(a)).not.toContain(token);
  const restored=await request('/guests/session','POST',undefined,cookie);expect(restored.status).toBe(200);expect((await restored.json()).id).toBe(a.id);
  const second=await request('/guests/session','POST',{displayName:'Minh',avatarKey:'amber'});const b=await second.json();expect(b.id).not.toBe(a.id);
  expect((await request('/me','GET',undefined,cookie)).status).toBe(200);
  expect((await request('/me','GET',undefined,'deadline_session=forged')).status).toBe(401);
  const invalid=await request('/me','PATCH',{displayName:'<script>x</script>'},cookie,a.csrfToken);expect(invalid.status).toBe(422);
  expect((await request('/me','PATCH',{avatarKey:'remote-url'},cookie,a.csrfToken)).status).toBe(422);
  expect((await request('/me','PATCH',{displayName:'Admin'},cookie,a.csrfToken)).status).toBe(422);
  expect((await request('/me','PATCH',{displayName:'Hà Vy'},cookie,'wrong')).status).toBe(403);
  expect((await request('/me','PATCH',{displayName:'Hà Vy'},cookie,a.csrfToken,'https://evil.invalid')).status).toBe(403);
  const update=await request('/me','PATCH',{displayName:'Hà Vy',avatarKey:'mint'},cookie,a.csrfToken);expect(update.status).toBe(200);expect((await update.json()).displayName).toBe('Hà Vy');
  const deleted=await request('/me','DELETE',undefined,cookie,a.csrfToken);expect(deleted.status).toBe(200);expect((await request('/me','GET',undefined,cookie)).status).toBe(401);
  expect((await request('/me','GET',undefined,second.headers.get('set-cookie')!.split(';')[0])).status).toBe(200);
 });
 it('rejects expired and revoked identities, purges expiry',async()=>{
  const a=await service.guests.create({displayName:'Expired',avatarKey:'fern'});await database.db.update(guests).set({expiresAt:new Date(Date.now()-1)}).where(eq(guests.id,a.guest.id));expect(await service.guests.find(a.token)).toBeNull();expect(await service.guests.purge()).toBe(1);
  const b=await service.guests.create({displayName:'Revoked',avatarKey:'rose'});await database.db.update(guests).set({revokedAt:new Date()}).where(eq(guests.id,b.guest.id));expect(await service.guests.find(b.token)).toBeNull();
 });
 it('returns real empty room configuration and safe missing-room error',async()=>{
  const cafes=await (await request('/cafes')).json();expect(cafes[0].occupancy).toBe(0);
  const list=await(await request('/cafes/dem-la/rooms')).json();expect(list[0]).toMatchObject({capacity:40,seatCapacity:30,occupancy:0});
  expect((await request('/rooms/missing')).status).toBe(404);
 });
 it('requires Origin, limits bootstrap and rejects oversized payloads',async()=>{
  expect((await request('/guests/session','POST',{displayName:'Abuse',avatarKey:'fern'},undefined,undefined,'https://evil.invalid')).status).toBe(403);
  const huge=await request('/guests/session','POST',{displayName:'x'.repeat(10000),avatarKey:'fern'});expect(huge.status).toBe(413);
  let limited=false;for(let i=0;i<14;i++){const response=await request('/guests/session','POST',{displayName:'Limit',avatarKey:'fern'});if(response.status===429){limited=true;expect((await response.json()).code).toBe('RATE_LIMITED');break;}}
  expect(limited).toBe(true);
 });
});
