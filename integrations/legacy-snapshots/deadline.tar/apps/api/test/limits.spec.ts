import {RateLimits} from '../src/common/limits';
describe('bounded limits',()=>{
 it('limits a window and reclaims expired entries',()=>{let now=0;const limiter=new RateLimits(()=>now,2);expect(limiter.take('a',1,10)).toBe(true);expect(limiter.take('a',1,10)).toBe(false);expect(limiter.take('b',1,10)).toBe(true);expect(limiter.take('c',1,10)).toBe(false);now=11;expect(limiter.take('c',1,10)).toBe(true);expect(limiter.size).toBeLessThanOrEqual(2);});
});
