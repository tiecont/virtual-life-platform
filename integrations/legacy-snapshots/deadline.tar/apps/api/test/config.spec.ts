import { envSchema } from '../src/config';
describe('configuration boundary',()=>{
 it('rejects missing database and invalid origin',()=>{expect(envSchema.safeParse({}).success).toBe(false);expect(envSchema.safeParse({DATABASE_URL:'not a url'}).success).toBe(false);});
 it('uses explicit same-origin defaults',()=>{expect(envSchema.parse({DATABASE_URL:'postgresql://localhost/deadline'}).PUBLIC_ORIGIN).toBe('http://localhost:3000');});
});
