import {createApp} from '../src/app';
describe('health semantics',()=>{
 it('reports live while unavailable database is not ready',async()=>{
  const previous=process.env.DATABASE_URL;
  process.env.DATABASE_URL='postgresql://invalid:invalid@127.0.0.1:1/unavailable';
  const service=await createApp({logging:false});
  try{
   await service.app.listen(0,'127.0.0.1');
   const url=await service.app.getUrl();
   expect((await fetch(url+'/healthz')).status).toBe(200);
   expect((await fetch(url+'/readyz')).status).toBe(503);
  }finally{await service.close();if(previous)process.env.DATABASE_URL=previous;else delete process.env.DATABASE_URL;}
 });
});
